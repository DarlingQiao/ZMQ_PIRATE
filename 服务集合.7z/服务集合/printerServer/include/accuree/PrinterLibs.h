#ifndef PRINTERLIBS_H
#define PRINTERLIBS_H

#ifdef PRINTERLIBS_EXPORTS
#define PRINTERLIBS_API __declspec(dllexport)
#else
#define PRINTERLIBS_API __declspec(dllimport)
#endif

#include <Windows.h>

#ifdef __cplusplus
extern "C"
{
#endif

#pragma region Constant

#define KCPORTTYPE_UNKNOWN		0
#define KCPORTYPE_COM			0x1
#define KCPORTYPE_ETH			0x2
#define KCPORTYPE_USB			0x4
#define KCPORTYPE_LPT			0x8
#define KCPORTYPE_PRN			0x10

#define HORIZONTALALIGNMENT_LEFT		-1
#define HORIZONTALALIGNMENT_CENTER		-2
#define HORIZONTALALIGNMENT_RIGHT		-3

#define BARCODE_TYPE_UPCA		0x41
#define BARCODE_TYPE_UPCE		0x42
#define BARCODE_TYPE_EAN13		0x43
#define BARCODE_TYPE_EAN8		0x44
#define BARCODE_TYPE_CODE39		0x45
#define BARCODE_TYPE_ITF		0x46
#define BARCODE_TYPE_CODABAR	0x47
#define BARCODE_TYPE_CODE93		0x48
#define BARCODE_TYPE_CODE128	0x49

#pragma endregion 

#pragma region Port

	PRINTERLIBS_API BOOL Port_OpenCom(TCHAR * pName, DWORD dwBaudrate, DWORD dwParity);
	PRINTERLIBS_API BOOL Port_OpenTcp(TCHAR * szIp, USHORT nPort);
	PRINTERLIBS_API BOOL Port_OpenUsb(TCHAR * pName);
	PRINTERLIBS_API BOOL Port_OpenLpt(TCHAR * pName);
	PRINTERLIBS_API BOOL Port_OpenPrn(TCHAR * pName);
	PRINTERLIBS_API VOID Port_CloseCom();
	PRINTERLIBS_API VOID Port_CloseTcp();
	PRINTERLIBS_API VOID Port_CloseUsb();
	PRINTERLIBS_API VOID Port_CloseLpt();
	PRINTERLIBS_API VOID Port_ClosePrn();
	PRINTERLIBS_API VOID Port_SetPort(DWORD dwPortType);

	PRINTERLIBS_API VOID Port_EnumCom(TCHAR * pBuf, int cbBuf, int * pcbNeeded, int * pcnReturned);
	PRINTERLIBS_API VOID Port_EnumLpt(TCHAR * pBuf, int cbBuf, int * pcbNeeded, int * pcnReturned);
	PRINTERLIBS_API VOID Port_EnumUSB(TCHAR * pBuf, int cbBuf, int * pcbNeeded, int * pcnReturned);
	PRINTERLIBS_API VOID Port_EnumPrn(TCHAR * pBuf, int cbBuf, int * pcbNeeded, int * pcnReturned);

#pragma endregion 

#pragma region Page

	PRINTERLIBS_API BOOL PAGE_PageEnter();
	PRINTERLIBS_API BOOL PAGE_PagePrint();
	PRINTERLIBS_API BOOL PAGE_PageExit();

	PRINTERLIBS_API BOOL PAGE_SetPrintArea(int left, int top, int right, int bottom, int direction);

	PRINTERLIBS_API BOOL PAGE_DrawString(TCHAR * pszString, int x, int y, int nWidthScale, int nHeightScale, int nFontType, int nFontStyle);
	PRINTERLIBS_API BOOL PAGE_DrawRect(int x, int y, int nWidth, int nHeight, int nColor);
	PRINTERLIBS_API BOOL PAGE_DrawBarcode(TCHAR * pszBarcodeContent, int x, int y, int nBarcodeUnitWidth, int nBarcodeHeight, int nHriFontType, int nHriFontPosition, int nBarcodeType);
	PRINTERLIBS_API BOOL PAGE_DrawQRCode(TCHAR * pszContent, int x, int y, int nQRCodeUnitWidth, int nVersion, int nEcLevel);
	PRINTERLIBS_API BOOL PAGE_DrawBitmap(TCHAR * FileName, int x, int y, int dwWidth, int dwHeight);

#pragma endregion

#pragma region Pos

	// ��ӡ
	PRINTERLIBS_API BOOL POS_TextOut(TCHAR * pszString, int x, int nWidthScale, int nHeightScale, int nFontType, int nFontStyle); // ��ӡ�ı�
	PRINTERLIBS_API BOOL POS_SetBarcode(TCHAR * pszBarcodeContent, int nBarcodeUnitWidth, int nBarcodeHeight, int nHriFontType, int nHriFontPosition, int nBarcodeType); // ��ӡ����
	PRINTERLIBS_API BOOL POS_SetQRCode(TCHAR * pszContent, int nQRCodeUnitWidth, int nVersion, int nEcLevel);	//��ӡQR��
	PRINTERLIBS_API BOOL POS_PrintPicture(TCHAR * FileName, DWORD dwWidth, DWORD dwHeight);	// ��ӡͼƬ
	PRINTERLIBS_API BOOL POS_SelfTest(); // ��ӡ�Բ�ҳ

	// ��ֽ
	PRINTERLIBS_API BOOL POS_FeedLine();
	PRINTERLIBS_API BOOL POS_FeedNLine(int nLine);
	PRINTERLIBS_API BOOL POS_FeedNDot(int nDot);

	// ��ѯ
	PRINTERLIBS_API BOOL POS_Query(unsigned char status[1]); // ��ѯ��ӡ��״̬
	PRINTERLIBS_API BOOL POS_RTQuery(unsigned char status[4]);	// ʵʱ��ѯ��ӡ��״̬
	PRINTERLIBS_API BOOL POS_TicketSucceed(int dwSendIndex); // ���ݴ�ӡ�����ѯ

	// ����
	PRINTERLIBS_API BOOL POS_SetMotionUnit(int nHorizontal, int nVertical);
	PRINTERLIBS_API BOOL POS_SetLineHeight(int nDistance);	// �����и�
	PRINTERLIBS_API BOOL POS_SetRightSpacing(int nDistance); // �����ַ��Ҽ��
	PRINTERLIBS_API BOOL POS_SetAlign(int nAlign); // ���ö���

	// ����
	PRINTERLIBS_API BOOL POS_Reset();	// ������λ
	PRINTERLIBS_API BOOL POS_KickOutDrawer(int nID, int nOnTimes, int nOffTimes); // ��Ǯ��
	PRINTERLIBS_API BOOL POS_CutPaper(int nMode);	// ֱ����ֽ
	PRINTERLIBS_API BOOL POS_FeedAndCut(int nDistance); // ��ӡ����ֽ[ ��ӡλ�õ��е�֮����� + nDistance ���������ƶ���λ��]Ȼ����ֽ
	PRINTERLIBS_API BOOL POS_Beep(int nBeepCount, int nBeepMillis); // ���������� nBeepCount ���д��� nBeepMillis ÿ�����е�ʱ�� = 100 * nBeemMillis ms

#pragma endregion

#ifdef __cplusplus
}
#endif

#endif