#include "YkPrinter.h"
#include "accuree/ThLPrinterDLL.h"
#include "accuree/helper.hpp"
#include "YkCustom_error_code.h"

YkPrinter::YkPrinter() {
}

YkPrinter::~YkPrinter() {
}

void YkPrinter::Open() {
	std::error_code ec;
	if (YkOpenDevice(13, 9600) != 0) {
		ec = std::make_error_code(std::errc::bad_file_descriptor);
		throw std::system_error(ec,"Open YkPrinter fail");
	}
}

void YkPrinter::Close() {
	if (YkCloseDevice() != 0)	
		throw YK_FAIL_;
}

bool YkPrinter::IsOnline() {
	if (YkGetState() < 0) {
		return false;
	}
	return true;
}

#if 1

#pragma region  YkPrinter_top
void YkPrinter::YkPtrOpenUSBDeviceBySerial(char *szSerial) {
	if (OpenUSBDeviceBySerial(szSerial) != 0) 
		throw YK_FAIL_;
}

	void YkPrinter::YkPtrEnumUSBDeviceSerials(char szSerials[10][20]) {
		if (EnumUSBDeviceSerials(szSerials) != 0)
		throw YK_FAIL_;
}

HANDLE YkPrinter::YkPtrOpenUsbPrtByName(LPCTSTR PrinterName) {
	return OpenUsbPrtByName(PrinterName);
}

void YkPrinter::YkPtrOpenDevice(int iport, int baud) {
	if (YkOpenDevice(iport, baud) != 0)
		throw YK_FAIL_;
}

void YkPrinter::YkPtrCloseDevice() {
	if (YkCloseDevice() != 0)
		throw YK_FAIL_;
}

int YkPrinter::YkPtrGetDeviceHandle() {
	return YkGetDeviceHandle();
}

int YkPrinter::YkPtrIsConnected() {
	return YkIsConnected();
}

void YkPrinter::YkPtrInitPrinter() {
	if (YkInitPrinter() != 0)
		throw YK_FAIL_;
}

void YkPrinter::YkPtrPrintStr(char *pstr) {
	if (YkPrintStr(pstr) != 0)
		throw YK_FAIL_;
}

void YkPrinter::YkPtrEnter() {
	if (YkEnter() != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrFeedPaper() {
	if (YkFeedPaper() != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrCancelPrintInPM() {
	if (YkCancelPrintInPM() != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrResponse(int n) {
	if (YkResponse(n) != 0)
		throw YK_FAIL_;
}

void YkPrinter::YkPtrTabMove() {
	if (YkTabMove() != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrPrintInPM() {
	if (YkPrintInPM() != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetCharRightSpace(int n) {
	if (YkSetCharRightSpace(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetFontStyle(int n) {
	if (YkSetFontStyle(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetAbsPrnPos(int nL, int nH) {
	if (YkSetAbsPrnPos(nL,nH) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrEnableUserDefineChar(int n) {
	if (YkEnableUserDefineChar(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetUserDefineChar(int c1, int c2, int x, unsigned char code[]) {
	if (YkSetUserDefineChar(c1,c2,x,code) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrEnableUnderLine(int n) {
	if (YkEnableUnderLine(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetDefaultLineSpace() {
	if (YkSetDefaultLineSpace() != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetLineSpace(float fLineSpace) {
	if (YkSetLineSpace(fLineSpace) != 0)
		throw YK_FAIL_;
}

void YkPrinter::YkPtrCancelUserDefChar(int n) {
	if (YkCancelUserDefChar(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetTabPos(char * tabstr) {
	if (YkSetTabPos(tabstr) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetEmphasized(int n) {
	if (YkSetEmphasized(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrOverlap(int n) {
	if (YkOverlap(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrPrnAndFeedPaper(int n) {
	if (YkPrnAndFeedPaper(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrEnablePM() {
	if (YkEnablePM() != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSelectFont(int n) {
	if (YkSelectFont(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetInterCharSet(int n) {
	if (YkSetInterCharSet(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrEnterSM() {
	if (YkEnterSM() != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetDirectionInPM(int n) {
	if (YkSetDirectionInPM(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrClockwiseD90(int n) {
	if (YkClockwiseD90(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetPrnAreaInPM(int left, int top, int width, int height) {
	if (YkSetPrnAreaInPM(left,top,width,height) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetRelPrnPos(int nL, int nH) {
	if (YkSetRelPrnPos(nL, nH) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetAlign(int n) {
	if (YkSetAlign(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetPaperSensor(int n) {
	if (YkSetPaperSensor(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetSensorToStopPrint(int n) {
	if (YkSetSensorToStopPrint(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrEnablePanelButton(int n) {
	if (YkEnablePanelButton(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrPrnAndFeedLine(int n) {
	if (YkPrnAndFeedLine(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetCharCodeTable(int n) {
	if (YkSetCharCodeTable(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrFeedToStartPos() {
	if (YkFeedToStartPos() != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetCharSize(int hsize, int vsize) {
	if (YkSetCharSize(hsize,vsize) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetAbsVertPosInPM(int nL, int nH) {
	if (YkSetAbsVertPosInPM(nL,nH) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrDoTestPrint(int n, int m) {
	if (YkDoTestPrint(n, m) != 0)
		throw YK_FAIL_;
}

void YkPrinter::YkPtrUserDefCmd(int m) {
	if (YkUserDefCmd(m) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetMemorySwitch(int n, int memory[]) {
	if (YkSetMemorySwitch(n,memory) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrGetMemorySwitch(int n, unsigned char memory[11]) {
	if (YkGetMemorySwitch(n, memory) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetBlackMarkParam(int a, int m, int nL, int nH) {
	if (YkSetBlackMarkParam(a, m, nL, nH) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrPrnAndBackToStd() {
	if (YkPrnAndBackToStd() != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrDefineControl(int n, int m) {
	if (YkDefineControl(n, m) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetHRIPos(int n) {
	if (YkSetHRIPos(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrGetPrinterID(int n) {
	if (YkGetPrinterID(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetLeftMargin(int nL, int nH) {
	if (YkSetLeftMargin(nL,nH) != 0) 
		throw YK_FAIL_;
}

void  YkPrinter::YkPtrToLineHome(int n) {
	if (YkToLineHome(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrCutPaper(int m, int n) {
	if (YkCutPaper(m,n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetPrnAreaWidth(int nL, int nH) {
	if (YkSetPrnAreaWidth(nL, nH) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetRelVertPosInPM(int nL, int nH) {
	if (YkSetRelVertPosInPM(nL, nH) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrEnableASB(int n) {
	if (YkEnableASB(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrEnableSmoothPrn(int n) {
	if (YkEnableSmoothPrn(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetHRICharStyle(int n) {
	if (YkSetHRICharStyle(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetBarCodeHeight(float fHeight) {
	if (YkSetBarCodeHeight(fHeight) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrPrintBarCode(int m, int n, char * barcode) {
	if (YkPrintBarCode(m,n,barcode) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrGetStatus(unsigned char n) {
	if (YkGetStatus(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrGetPrinterStatus(unsigned char n) {
	if (YkGetPrinterStatus(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetBarCodeWidth(float fWdith) {
	if (YkSetBarCodeWidth(fWdith) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetChineseFontStyle(int n) {
	if (YkSetChineseFontStyle(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrEnableChineseMode() {
	if (YkEnableChineseMode() != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrDisableChineseMode() {
	if (YkDisableChineseMode() != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrEnableChineseUnderLine(int n) {
	if (YkEnableChineseUnderLine(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetUserDefChinese(int c1, int c2, int code[]) {
	if (YkSetUserDefChinese(c1,c2,code) != 0)
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetUserDefChineseArea(int n) {
	if (YkSetUserDefChineseArea(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetChineseLeftRightSpace(int n1, int n2) {
	if (YkSetChineseLeftRightSpace(n1,n2) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetChinese4TimesSize(int n) {
	if (YkSetChinese4TimesSize(n) != 0) 
		throw YK_FAIL_;
}


void YkPrinter::YkPtrEnableUpsidedown(int n) {
	if (YkEnableUpsidedown(n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrPrintDefineBitmap(int m, int n) {
	if (YkPrintDefineBitmap(m,n) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrDefineBitmap(char *szBmpFile) {
	if (YkDefineBitmap(szBmpFile) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrPrintBitmap(char *szBmpFile, int m) {
	if (YkPrintBitmap(szBmpFile,m) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrDownloadBitmapAndPrint(char *szBmpFile, int m) {
	if (YkDownloadBitmapAndPrint(szBmpFile, m) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetCashBoxDriveMode(int m, int t1, int t2) {
	if (YkSetCashBoxDriveMode(m,t1,t2) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrSetCallBack(CallBack pCallBack) {
	if (YkSetCallBack(pCallBack) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrEnableCallBack(int enable) {
	if (YkEnableCallBack(enable) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrDirectIO(unsigned char *pdata, int len) {
	if (YkDirectIO(pdata,len) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrWriteSerialNo(char *pdata) {
	if (YkWriteSerialNo(pdata) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrReadSerialNo(char *pdata) {
	if (YkReadSerialNo(pdata) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrPrintRasterBmp(char *szBmpFile) {
	if (YkPrintRasterBmp(szBmpFile) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::YkPtrGetState() {
	if (YkGetState() != 0) 
		throw YK_FAIL_;
}
#pragma endregion


////ͨ�ú���
#pragma region YkPriinter_Ganeral_function 
void YkPrinter::GfSetPrintFont(int iInDoubleHeight, int iInDoubleWide, int iInUnderLine) {
	if (SetPrintFont(iInDoubleHeight, iInDoubleWide, iInUnderLine) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfSetLeftDistance(int iInDistance) {
	if (SetLeftDistance(iInDistance) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfSetRowDistance(int iInDistance) {
	if (SetRowDistance(iInDistance) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfPrintBmp(char* pcInBmpFile) {
	if (PrintBmp(pcInBmpFile) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfPrintString(char* pcInstring) {
	if (PrintString(pcInstring) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfPrintLine(char* pcInstring) {
	if (PrintLine(pcInstring) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfCutPaper(int iInCutMode) {
	if (CutPaper(iInCutMode) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfSetBlackMark(int iInn) {
	if (SetBlackMark(iInn) != 0) 
		throw YK_FAIL_;
}


/*
������������ֽ
��������			����		��������				��ע
��ڲ�����
fInDistance			float		mm		��λ:mm
����ֵ��					int								0:�ɹ�
1:ʧ��
*/
void YkPrinter::GfFeedPaper(float fInDistance) {
// 	if (FeedPaper(fInDistance) != 0)
// 		throw YK_FAIL_;
}


//int WINAPI PrintRasterBmp(unsigned char *szBmpFileData,int len);

void YkPrinter::GfSetPDF417ModWidth(int ModWidth) {
	if (SetPDF417ModWidth(ModWidth) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfSetPDF417ModHeight(int ModHeight) {
	if (SetPDF417ModHeight(ModHeight) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfSetPDF417Level(int Level) {
	if (SetPDF417Level(Level) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfSetStdPDF417(int iStd) {
	if (SetStdPDF417(iStd) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfSetPDF417RowCol(int iRow , int iCol) {
	if (SetPDF417RowCol(iRow, iCol) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfPrintPDF417Code(unsigned char *pCode, int iLen) {
	if (PrintPDF417Code(pCode, iLen) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfSetQRModSize(int ModWidth) {
	if (SetQRModSize(ModWidth) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfSetQRLevel(int Level) {
	if (SetQRLevel(Level) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfPrintQRCode(unsigned char *pCode, int iLen) {
	if (PrintQRCode(pCode,iLen) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfSetAbsPrnPos(float fPos) {
	if (SetAbsPrnPos(fPos) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfPrint2DCode(int iType, unsigned char *pCode, int iLen) {
	if (Print2DCode(iType,pCode,iLen) != 0) 
		throw YK_FAIL_;
}

void YkPrinter::GfInitPrinter() {
	if (InitPrinter() != 0) 
		throw YK_FAIL_;
}


//////2016-12-13 �¶���һ��ͨ�ã����׼���������Ժ���ƹ���ͻ������ͻ����������������Ӻ��� 

HANDLE YkPrinter::GfPOS_Open(LPCTSTR lpName,int nComBaudrate,int nParam) {
	return POS_Open(lpName, nComBaudrate, nParam);
}

void YkPrinter::GfPOS_Close(void) {
	int ret = POS_Close();
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_Close");
	}
}

void YkPrinter::GfPOS_Reset(void) {
	int ret = POS_Reset();
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_Reset");
	}
}

void YkPrinter::GfPOS_SetMode(int nPrintMode) {
	int ret = POS_SetMode(nPrintMode);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_SetMode");
	}
}

void YkPrinter::GfPOS_SetMotionUnit(int nHorizontalMU, int nVerticalMU) {
	int ret = POS_SetMotionUnit(nHorizontalMU, nVerticalMU);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_SetMotionUnit");
	}
}


void YkPrinter::GfPOS_SetCharSetAndCodePage(int nCharSet, int nCodePage){
	int ret = POS_SetCharSetAndCodePage(nCharSet, nCodePage);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_SetCharSetAndCodePage");
	}
}

void YkPrinter::GfPOS_FeedLine(void) {
	int ret = POS_FeedLine();
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_FeedLine");
	}
}

void YkPrinter::GfPOS_SetLineSpacing(int nDistance) {
	int ret = POS_SetLineSpacing(nDistance);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_SetLineSpacing");
	}
}

void YkPrinter::GfPOS_SetRightSpacing(int nDistance) {
	int ret = POS_SetRightSpacing(nDistance);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_SetRightSpacing");
	}
}

void YkPrinter::GfPOS_PreDownloadBmpToRAM(char *pszPath, int nID) {
	int ret = POS_PreDownloadBmpToRAM(pszPath, nID);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_PreDownloadBmpToRAM");
	}
}

void YkPrinter::GfPOS_PreDownloadBmpsToFlash(char* pszPaths[], int nCount) {
	int ret = POS_PreDownloadBmpsToFlash(pszPaths, nCount);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_PreDownloadBmpsToFlash");
	}
}

void YkPrinter::GfPOS_QueryStatus(char *pszStatus, int nTimeouts) {
	int ret = POS_QueryStatus(pszStatus, nTimeouts);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_QueryStatus");
	}
}

void YkPrinter::GfPOS_RTQueryStatus(char *pszStatus) {
	int ret = POS_RTQueryStatus(pszStatus);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_RTQueryStatus");
	}
}

void YkPrinter::GfPOS_NETQueryStatus(char *ipAddress, char *pszStatus) {
	int ret = POS_NETQueryStatus(ipAddress,pszStatus);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_NETQueryStatus");
	}
}

void YkPrinter::GfPOS_KickOutDrawer(int nID, int nOnTimes, int nOffTimes) {
	int ret = POS_KickOutDrawer(nID, nOnTimes,nOffTimes);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_KickOutDrawer");
	}
}

void YkPrinter::GfPOS_CutPaper(int nMode, int nDistance) {
	int ret = POS_CutPaper(nMode,nDistance);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_CutPaper");
	}
}

void YkPrinter::GfPOS_StartDoc() {
	if (!POS_StartDoc())
		throw YK_FAIL_;
}

void YkPrinter::GfPOS_EndDoc() {
	if (!POS_EndDoc())
		throw YK_FAIL_;
}

void YkPrinter::GfPOS_BeginSaveFile(LPCTSTR lpFileName, BOOL bToPrinter) {
	POS_BeginSaveFile(lpFileName,bToPrinter);
}

void YkPrinter::GfPOS_EndSaveFile() {
	POS_EndSaveFile();
}

void YkPrinter::GfPOS_S_SetAreaWidth(int nWidth) {
	int ret = POS_S_SetAreaWidth(nWidth);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_S_SetAreaWidth");
	}
}

void YkPrinter::GfPOS_S_TextOut(char *pszString, int nOrgx, int nWidthTimes, 
																int nHeightTimes, int nFontType, int nFontStyle) {
	int ret = POS_S_TextOut(pszString,nOrgx,nWidthTimes,nHeightTimes,nFontType,nFontStyle);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_S_TextOut");
	}
}

void YkPrinter::GfPOS_S_DownloadAndPrintBmp(char *pszPath, int nOrgx, int nMode) {
	int ret = POS_S_DownloadAndPrintBmp(pszPath, nOrgx, nMode);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_S_DownloadAndPrintBmp");
	}
}

void YkPrinter::GfPOS_S_PrintBmpInRAM(int nID, int nOrgx, int nMode) {
	int ret = POS_S_PrintBmpInRAM(nID, nOrgx, nMode);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_S_PrintBmpInRAM");
	}
}

void YkPrinter::GfPOS_S_PrintBmpInFlash(int nID, int nOrgx, int nMode) {
	int ret = POS_S_PrintBmpInFlash(nID, nOrgx, nMode);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_S_PrintBmpInFlash");
	}
}

void YkPrinter::GfPOS_S_SetBarcode(char *pszInfoBuffer, int nOrgx, int nType, int nWidthX,
												int nHeight, int nHriFontType, int nHriFontPosition, int nBytesToPrint) {
	int ret = POS_S_SetBarcode(pszInfoBuffer,nOrgx,nType,nWidthX,nHeight,nHriFontType,nHriFontPosition,nBytesToPrint);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_S_SetBarcode");
	}
}

void YkPrinter::GfPOS_PL_SetArea(int nOrgx, int nOrgy, int nWidth, int nHeight, int nDirection) {
	int ret = POS_PL_SetArea(nOrgx,nOrgy,nWidth,nHeight,nDirection);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_PL_SetArea");
	}
}

void YkPrinter::GfPOS_PL_TextOut(char *pszString, int nOrgx, int nOrgy, int nWidthTimes,
											int nHeightTimes, int nFontType, int nFontStyle) {
	int ret = POS_PL_TextOut(pszString,nOrgx,nOrgy,nWidthTimes,nHeightTimes,nFontType,nFontStyle);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_PL_TextOut");
	}
}

void YkPrinter::GfPOS_PL_DownloadAndPrintBmp(char *pszPath, int nOrgx, int nOrgy, int nMode) {
	int ret = POS_PL_DownloadAndPrintBmp(pszPath, nOrgx, nOrgy,nMode);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_PL_DownloadAndPrintBmp");
	}
}

void YkPrinter::GfPOS_PL_PrintBmpInRAM(int nID, int nOrgx, int nOrgy, int nMode) {
	int ret = POS_PL_PrintBmpInRAM(nID,nOrgx,nOrgy,nMode);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_PL_PrintBmpInRAM");
	}
}

void YkPrinter::GfPOS_PL_SetBarcode(char *pszInfoBuffer, int nOrgx, int nOrgy, int nType, int nWidthX,
												int nHeight, int nHriFontType, int nHriFontPosition, int nBytesToPrint) {
	int ret = POS_PL_SetBarcode(pszInfoBuffer,nOrgx,nOrgy,nType,nWidthX,nHeight,nHriFontType,nHriFontPosition,nBytesToPrint);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_PL_SetBarcode");
	}
}

void YkPrinter::GfPOS_PL_Print(void) {
	int ret = POS_PL_Print();
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_PL_Print");
	}
}

void YkPrinter::GfPOS_PL_Clear(void) {
	int ret = POS_PL_Clear();
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_PL_Clear");
	}
}

void YkPrinter::GfPOS_WriteFile(HANDLE hPort, char *pszData, int nBytesToWrite) {
	int ret = POS_WriteFile(hPort,pszData,nBytesToWrite);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_WriteFile");
	}
}

void YkPrinter::GfPOS_ReadFile(HANDLE hPort, char *pszData, int nBytesToRead, int nTimeouts) {
	int ret = POS_ReadFile(hPort, pszData, nBytesToRead,nTimeouts);
	if (ret != POS_SUCCESS)	{
		std::error_code e(ret, custom_category);
		throw std::system_error(e, "POS_ReadFile");
	}
}

HANDLE YkPrinter::GfPOS_SetHandle(HANDLE hNewHandle) {
	return POS_SetHandle(hNewHandle);
}

int YkPrinter::GfPOS_GetSWVersionInfo(int *pnMajor, int *pnMinor) {
	return POS_GetSWVersionInfo(pnMajor,pnMinor);
}
#pragma endregion

#endif