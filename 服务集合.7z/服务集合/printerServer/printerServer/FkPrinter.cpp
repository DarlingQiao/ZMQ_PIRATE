#include "FkPrinter.h"
#include "accuree/helper.hpp"
#include "accuree/PrinterLibs.h"


FkPrinter::FkPrinter() {
}


FkPrinter::~FkPrinter() {
}


#pragma region self_pay 
void FkPrinter::OpenUsb() {
	std::error_code ec;
	if (Port_OpenUsb(_T(""))) {
		Port_SetPort(KCPORTYPE_USB);
	}
	else {
		ec = std::make_error_code(std::errc::bad_file_descriptor);
		throw std::system_error(ec, "open USB FkPrinter fail");
	}
}

void FkPrinter::CloseUsb() {
	Port_CloseUsb();
}

bool FkPrinter::IsOnline() {
	return POS_SetAlign(0) == TRUE ? true : false;
}

bool FkPrinter::PrintRawData(const std::string& strData) {
	std::wstring wide_data = helper::string_to_wstring(strData);
	return PrintRawData(wide_data);
}

bool FkPrinter::PrintRawData(const std::wstring& wide_data) {
	POS_SetAlign(0);
	if (!POS_TextOut(const_cast<wchar_t*>(wide_data.c_str()),
		0, 0, 0, 0, 0)) {
		return false;
	}
	POS_FeedLine();
	POS_FeedLine();
	POS_FeedAndCut(0);
	int dwSendIndex = 1;
	POS_TicketSucceed(dwSendIndex++);
	return true;
}

bool FkPrinter::PrintRawData(const std::wstring& union_pay_data_f,
														 const std::wstring& union_pay_data_l,
														 const std::wstring& sign_data) {
	POS_SetAlign(0);
	if (!POS_TextOut(const_cast<wchar_t*>(union_pay_data_f.c_str()),
		0, 0, 0, 0, 0)) {
		return false;
	}
	POS_SetAlign(1);
	if (!POS_PrintPicture(const_cast<wchar_t*>(sign_data.c_str()),
		350, 100)) {
		return false;
	}
	POS_SetAlign(1);
	if (!POS_TextOut(const_cast<wchar_t*>(union_pay_data_l.c_str()),
		0, 0, 0, 0, 0)) {
		return false;
	}

	POS_FeedLine();
	POS_FeedLine();
	POS_FeedLine();
	POS_FeedAndCut(0);
	int dwSendIndex = 1;
	POS_TicketSucceed(dwSendIndex++);
	return true;
}

bool FkPrinter::PrintRawData(const std::wstring& union_pay_data_f,
														 const std::wstring& union_pay_data_l) {
	POS_SetAlign(0);
	if (!POS_TextOut(const_cast<wchar_t*>(union_pay_data_f.c_str()),
		0, 0, 0, 0, 0)) {
		return false;
	}
	POS_SetAlign(1);
	if (!POS_TextOut(const_cast<wchar_t*>(union_pay_data_l.c_str()),
		0, 0, 0, 0, 0)) {
		return false;
	}

	POS_FeedLine();
	POS_FeedLine();
	POS_FeedAndCut(0);
	int dwSendIndex = 1;
	POS_TicketSucceed(dwSendIndex++);
	return true;
}
#pragma endregion 

#pragma region Port
void FkPrinter::PortOpenCom(TCHAR * pName, DWORD dwBaudrate, DWORD dwParity) {
	if (!Port_OpenCom(pName, dwBaudrate, dwParity)) {
		std::error_code ec;
		ec = std::make_error_code(std::errc::bad_file_descriptor);
		throw std::system_error(ec, __FUNCTION__);
	}
}

void FkPrinter::PortOpenTcp(TCHAR * szIp, USHORT nPort) {
	if (!Port_OpenTcp(szIp, nPort))
		throw FK_FAIL_;
}

void FkPrinter::PortOpenUsb(TCHAR * pName) {
	if (!Port_OpenUsb(pName))
		throw FK_FAIL_;
}

void FkPrinter::PortOpenLpt(TCHAR * pName) {
	if (!Port_OpenLpt(pName))
		throw FK_FAIL_;
}

void FkPrinter::PortOpenPrn(TCHAR * pName) {
	if (!Port_OpenPrn(pName)){
		throw FK_FAIL_;
	}
}

void FkPrinter::PortCloseCom() {
	Port_CloseCom();
}

void FkPrinter::PortCloseTcp() {
	Port_CloseTcp();
}

void FkPrinter::PortCloseUsb() {
	Port_CloseUsb();
}

void FkPrinter::PortCloseLpt() {
	Port_CloseLpt();
}
void FkPrinter::PortClosePrn() {
	Port_ClosePrn();
}
void FkPrinter::PortSetPort(DWORD dwPortType) {
	Port_SetPort(dwPortType);
}

void FkPrinter::PortEnumCom(TCHAR * pBuf, int cbBuf, int * pcbNeeded, int * pcnReturned) {
	Port_EnumCom(pBuf,cbBuf,pcbNeeded,pcnReturned);
}

void FkPrinter::PortEnumLpt(TCHAR * pBuf, int cbBuf, int * pcbNeeded, int * pcnReturned) {
	Port_EnumLpt(pBuf,cbBuf,pcbNeeded,pcnReturned);
}

void FkPrinter::PortEnumUSB(TCHAR * pBuf, int cbBuf, int * pcbNeeded, int * pcnReturned) {
	Port_EnumUSB(pBuf, cbBuf, pcbNeeded, pcnReturned);
}

void FkPrinter::PortEnumPrn(TCHAR * pBuf, int cbBuf, int * pcbNeeded, int * pcnReturned) {
	Port_EnumPrn(pBuf,cbBuf,pcbNeeded,pcnReturned);
}
#pragma endregion 

#pragma region Page
void FkPrinter::PAGEPageEnter() {
	if (!PAGE_PageEnter())
		throw FK_FAIL_;
}

void FkPrinter::PAGEPagePrint() {
	if (!PAGE_PagePrint())
		throw FK_FAIL_;
}

void FkPrinter::PAGEPageExit() {
	if (!PAGE_PageExit())
		throw FK_FAIL_;
}

void FkPrinter::PAGESetPrintArea(int left, int top, int right, int bottom, int direction) {
	if (!PAGE_SetPrintArea(left, top, right, bottom, direction))
		throw FK_FAIL_;
}

void FkPrinter::PAGEDrawString(TCHAR * pszString, int x, int y, int nWidthScale, int nHeightScale, 
																int nFontType, int nFontStyle) {
	if (!PAGE_DrawString(pszString, x, y, nWidthScale, nHeightScale, nFontType, nFontStyle))
		throw FK_FAIL_;
}

void FkPrinter::PAGEDrawRect(int x, int y, int nWidth, int nHeight, int nColor) {
	if (!PAGE_DrawRect(x, y, nWidth, nHeight, nColor))
		throw FK_FAIL_;
}

void FkPrinter::PAGEDrawBarcode(TCHAR * pszBarcodeContent, int x, int y, int nBarcodeUnitWidth,
																 int nBarcodeHeight, int nHriFontType, int nHriFontPosition, int nBarcodeType) {
	if (!PAGE_DrawBarcode(pszBarcodeContent, x, y, nBarcodeUnitWidth, 
												nBarcodeHeight, nHriFontType, nHriFontPosition, nBarcodeType))
		throw FK_FAIL_;
}

void FkPrinter::PAGEDrawQRCode(TCHAR * pszContent, int x, int y, int nQRCodeUnitWidth, int nVersion, int nEcLevel) {
	if (!PAGE_DrawQRCode(pszContent, x, y, nQRCodeUnitWidth, nVersion, nEcLevel))
		throw FK_FAIL_;
}

void FkPrinter::PAGEDrawBitmap(TCHAR * FileName, int x, int y, int dwWidth, int dwHeight) {
	if (!PAGE_DrawBitmap(FileName, x, y, dwWidth, dwHeight))
		throw FK_FAIL_;
}
#pragma endregion

#pragma region Pos
// ��ӡ
void FkPrinter::POSTextOut(TCHAR * pszString, int x, int nWidthScale, int nHeightScale, int nFontType, int nFontStyle) {
	if (!POS_TextOut(pszString, x, nWidthScale, nHeightScale, nFontType, nFontStyle))
		throw FK_FAIL_;
}

void FkPrinter::POSSetBarcode(TCHAR * pszBarcodeContent, int nBarcodeUnitWidth, int nBarcodeHeight,
																int nHriFontType, int nHriFontPosition, int nBarcodeType) {
	if (!POS_SetBarcode(pszBarcodeContent, nBarcodeUnitWidth, nBarcodeHeight, nHriFontType, nHriFontPosition, nBarcodeType))
		throw FK_FAIL_;
}

void FkPrinter::POSSetQRCode(TCHAR * pszContent, int nQRCodeUnitWidth, int nVersion, int nEcLevel) {
	if (!POS_SetQRCode(pszContent, nQRCodeUnitWidth, nVersion, nEcLevel))
		throw FK_FAIL_;
}

void FkPrinter::POSPrintPicture(TCHAR * FileName, DWORD dwWidth, DWORD dwHeight) {
	if (!POS_PrintPicture(FileName, dwWidth, dwHeight))
		throw FK_FAIL_;
}

void FkPrinter::POSSelfTest() {
	if (!POS_SelfTest())
		throw FK_FAIL_;
}

// ��ֽ
void FkPrinter::POSFeedLine() {
	if (!POS_FeedLine())
		throw FK_FAIL_;
}

void FkPrinter::POSFeedNLine(int nLine) {
	if (!POS_FeedNLine(nLine))
		throw FK_FAIL_;
}

void FkPrinter::POSFeedNDot(int nDot) {
	if (!POS_FeedNDot(nDot))
		throw FK_FAIL_;
}

// ��ѯ
void FkPrinter::POSQuery(unsigned char status[1]) {
	if (!POS_Query(status + 1))
		throw FK_FAIL_;
}

void FkPrinter::POSRTQuery(unsigned char status[4]) {
	if (!POS_RTQuery(status + 4))
		throw FK_FAIL_;
}

void FkPrinter::POSTicketSucceed(int dwSendIndex) {
	if (!POS_TicketSucceed(dwSendIndex))
		throw FK_FAIL_;
}

// ����
void FkPrinter::POSSetMotionUnit(int nHorizontal, int nVertical) {
	if(!POS_SetMotionUnit(nHorizontal, nVertical))
		throw FK_FAIL_;
}

void FkPrinter::POSSetLineHeight(int nDistance) {
	if(!POS_SetLineHeight(nDistance))
		throw FK_FAIL_;
}

void FkPrinter::POSSetRightSpacing(int nDistance) {
	/*return TRUE;//POS_SetRightSpacing(nDistance);*/
	//POS_SetRightSpacing
		throw FK_UNKNOWN_;
}

void FkPrinter::POSSetAlign(int nAlign) {
	if (!POS_SetAlign(nAlign))
		throw FK_FAIL_;
}

// ����
void FkPrinter::POSReset() {
	if (!POS_Reset())
		throw FK_FAIL_;
}

void FkPrinter::POSKickOutDrawer(int nID, int nOnTimes, int nOffTimes) {
	if (!POS_KickOutDrawer(nID, nOnTimes, nOffTimes))
		throw FK_FAIL_;
}

void FkPrinter::POSCutPaper(int nMode) {
	if (!POS_CutPaper(nMode))
		throw FK_FAIL_;
}

void FkPrinter::POSFeedAndCut(int nDistance) {
	if (!POS_FeedAndCut(nDistance))
		throw FK_FAIL_;
}

void FkPrinter::POSBeep(int nBeepCount, int nBeepMillis) {
	if (!POS_Beep(nBeepCount, nBeepMillis))
		throw FK_FAIL_;
}
#pragma endregion