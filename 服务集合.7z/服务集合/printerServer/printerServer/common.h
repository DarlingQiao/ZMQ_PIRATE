#ifndef __COMMON_H__
#define __COMMON_H__
#include "exception.h"
#include <iostream>
#include <fstream>
//json�������궨��
#define CHECKJSONINT(_NAME,_ROOT,_TYPE) \
	if(!(_ROOT).isMember((_NAME)))\
		  {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
		  }\
	if(!(_ROOT)[(_NAME)].isInt())\
		  {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
		  }

#define CHECKJSONSTRING(_NAME,_ROOT,_TYPE) \
	if(!(_ROOT).isMember((_NAME)))\
		  {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
		  }\
	if(!(_ROOT)[(_NAME)].isString())\
		  {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
		  }

#define CHECKJSONOBJECT(_NAME,_ROOT,_TYPE) \
	if(!(_ROOT).isMember((_NAME)))\
		  {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
		  }\
	if(!(_ROOT)[(_NAME)].isObject())\
		  {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
		  }

#define CHECKJSONARRAY(_NAME,_ROOT,_TYPE) \
	if(!(_ROOT).isMember((_NAME)))\
		  {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
		  }\
	if(!(_ROOT)[(_NAME)].isArray())\
		  {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
		  }

std::string ErrCodeConver(int value) {
	std::string  str;
	char strBuff[64] = { 0 };
	sprintf(strBuff, "%d", value);
	str = strBuff;
	return str;
}

bool IsFileExist(std::string &filePath) {
	std::fstream _file;
	_file.open(filePath, std::ios::in);
	if (!_file)	{
		//cout << FILENAME << "û�б�����";
		return false;
	}	else	{
		//cout << FILENAME << "�Ѿ�����";
		return true;
	}
	return true;
}

#endif