#ifndef JNI_EXCEPTION_HPP_
#define JNI_EXCEPTION_HPP_

#include <string>
#include <exception>

/***********************************************************************
 �쳣�������ඨ��
***********************************************************************/
class ProcessException : public std::exception {
public:
	ProcessException(const std::string &_error,
		const std::string &errorcode,
		int line,
		const std::string& filename,
		const std::string &type);

	virtual const std::string& getErrorcode() const;
	virtual int getLine() const;
	virtual const std::string& getFilename() const;
	virtual const std::string& getType() const;

private:
	int _line;
	std::string _filename;
	std::string _errorcode;
	std::string _type;
};

/***********************************************************************
 A02 session��֤ʧ��
***********************************************************************/
class SessionExcption : public ProcessException {
public:
	SessionExcption(int line, const std::string& filename, const std::string &type);
};

#define THROW_A02_EXCEPTION(name) \
	throw SessionExcption(__LINE__, __FILE__, name);

/***********************************************************************
 A03 �ύ��������
***********************************************************************/
class A03_ProcessException : public ProcessException {
public:
	A03_ProcessException(const std::string &name, int line, const std::string& filename, const std::string &type);
};

#define THROW_A03_EXCEPTION(name,type) \
	throw A03_ProcessException(name, __LINE__, __FILE__, type);

/***********************************************************************
 A05 ҵ�����̺Ŵ���
***********************************************************************/
class A05_ProcessException : public ProcessException {
public:
	A05_ProcessException(int line, const std::string& filename, const std::string& type);
};

#define THROW_A05_EXCEPTION(name) \
	throw A05_ProcessException(__LINE__, __FILE__, name);

/***********************************************************************
 A07 �������ڲ�����
***********************************************************************/
class A07_ProcessException : public ProcessException {
public:
	A07_ProcessException(const std::string &type,int line, const std::string& filename);
};

#define THROW_A07_EXCEPTION(name) \
	throw A07_ProcessException((name), __LINE__, __FILE__);

/***********************************************************************
 A08 Ȩ����֤ʧ��
***********************************************************************/
class A08_ProcessException : public ProcessException {
public:
	A08_ProcessException(int line, const std::string& filename, const std::string &type);
};

#define THROW_A08_EXCEPTION(name) \
	throw A08_ProcessException(__LINE__, __FILE__, name);

/***********************************************************************
 A10 �������ڲ���ʱ
***********************************************************************/
class A10_ProcessException : public ProcessException {
public:
	A10_ProcessException(const std::string &type,int line, const std::string& filename);
};

#define THROW_A10_EXCEPTION(name) \
	throw A10_ProcessException((name), __LINE__, __FILE__);

#endif
