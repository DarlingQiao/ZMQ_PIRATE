#include "PrinterDevice.h"
#include "accuree/helper.hpp"
#include "common.h"
#include <tchar.h>
#define Error_Invalid_value_ -2 //��Ч���ַ�

PrinterDevice::PrinterDevice() {
}


PrinterDevice::~PrinterDevice() {
}

std::string PrinterDevice::OutJson() {
	return write_.write(root_);
}

void PrinterDevice::ParseMessageCmd(zmsg_t *request) {
	if (request == NULL) {
		return;
	}
	Json::Reader read;
	zframe_t *data = zmsg_last(request);
	char *str = zframe_strdup(data);
	std::string buffer = str;
	free(str);
	str = NULL;
	root_.clear();
	head_.clear();
	body_.clear();
	if (!read.parse(buffer, root_)) {
		UnknownCmd("unkonwn", "-204", "json ��������");
		return;
	}
	if (!IsJsonCheck())	{
		return;
	}
	head_ = root_["head"];
	body_ = root_["body"];
	std::string code = head_["code"].asString();
	std::string device = head_["device"].asString();
	std::string deviceType = head_["deviceType"].asString();
	if (strcmp(deviceType.c_str(),"FK") == 0)	{
		;
	}
	else if (strcmp(deviceType.c_str(), "YK") == 0)	{
		;
	}	else {
		UnknownCmd(code, "-204", "��֧�ֵ��豸����");
		return;
	}
	PrinterFunction(code);
}

void PrinterDevice::Open() {
	std::string deviceType = head_["deviceType"].asString();
	if (strcmp(deviceType.c_str(),"FK") == 0)	{
		fkPrinter_.OpenUsb();
	}	else if (strcmp(deviceType.c_str(), "YK") == 0) {
		ykPrinter_.Open();
	}
	body_.clear();
}

void PrinterDevice::Close() {
	std::string deviceType = head_["deviceType"].asString();
	if (strcmp(deviceType.c_str(), "FK") == 0)	{
		fkPrinter_.CloseUsb();
	}
	else if (strcmp(deviceType.c_str(), "YK") == 0) {
		ykPrinter_.Close();
	}
	body_.clear();
}

void PrinterDevice::IsOnline() {
	std::string deviceType = head_["deviceType"].asString();
	body_.clear();
	std::string online = "off";
	if (strcmp(deviceType.c_str(), "FK") == 0)	{
		if (fkPrinter_.IsOnline()) {
		online = "on";
		}
	} else if (strcmp(deviceType.c_str(), "YK") == 0) {
		if (ykPrinter_.IsOnline())	{
		online = "on";
		}
	}
	body_["online"] = online;
}

void PrinterDevice::PtrPrintStr() {
	std::string deviceType = head_["deviceType"].asString();
	std::string data = body_["data"].asString();
	if (strcmp(deviceType.c_str(), "FK") == 0)	{
		int x = body_["x"].asInt();
		int height = body_["height"].asInt();
		int width = body_["width"].asInt();
		int fontType = body_["fontType"].asInt();
		int fontStyle = body_["fontStyle"].asInt();
		fkPrinter_.POSTextOut(const_cast<wchar_t*>(helper::string_to_wstring(data).c_str()),
													x, width, height, fontType,fontStyle);
	}	else if (strcmp(deviceType.c_str(), "YK") == 0) {
		ykPrinter_.YkPtrPrintStr((char*)data.c_str());
	}
	body_.clear();
}

void PrinterDevice::PtrPrintPicture() {
	std::string deviceType = head_["deviceType"].asString();
	std::string filePath = body_["filePath"].asString();
	if (filePath.length() <= 0 || !IsFileExist(filePath))	{
		std::error_code ec;
		ec = std::make_error_code(std::errc::address_not_available);
		throw std::system_error(ec, "��Ч���ļ�·��");
	}
	if (strcmp(deviceType.c_str(), "FK") == 0)	{
		int height = body_["height"].asInt();
		int width = body_["width"].asInt();
		fkPrinter_.POSPrintPicture(const_cast<wchar_t*>(helper::string_to_wstring(filePath).c_str()), width, height);
	}
	else if (strcmp(deviceType.c_str(), "YK") == 0) {
		//��ӡlogo
		//ykPrinter_.GfPrintBmp((char*)filePath.c_str());
		//
		int ddi = body_["ddi"].asInt();
		ykPrinter_.YkPtrPrintBitmap((char*)filePath.c_str(),ddi);
	}
	body_.clear();
}

void PrinterDevice::PtrPrintBarcode() {
	std::string deviceType = head_["deviceType"].asString();
	std::string data = body_["data"].asString();
	if (strcmp(deviceType.c_str(), "FK") == 0)	{
		int height = body_["barCodeHeight"].asInt();
		int width = body_["barCodeWidth"].asInt();
		int fontType = body_["fontType"].asInt();
		int fontPositin = body_["fontStyle"].asInt();
		int barCodeType = body_["barCodeType"].asInt();
		fkPrinter_.POSSetBarcode(const_cast<wchar_t*>(helper::string_to_wstring(data).c_str()),
			width, height, fontType, fontPositin, barCodeType);
	}
	else if (strcmp(deviceType.c_str(), "YK") == 0) {
		int barCodeType = body_["barCodeType"].asInt();
		int charNum = body_["charNum"].asInt();
		ykPrinter_.YkPtrPrintBarCode(barCodeType, charNum, (char*)data.c_str());
	}
	body_.clear();
}

void PrinterDevice::PtrPrintQR() {
	std::string deviceType = head_["deviceType"].asString();
	std::string data = body_["data"].asString();
	if (strcmp(deviceType.c_str(), "FK") == 0)	{
		int width = body_["barCodeWidth"].asInt();
		int version = body_["version"].asInt();
		int eclevel = body_["eclevel"].asInt();
		fkPrinter_.POSSetQRCode(const_cast<wchar_t*>(helper::string_to_wstring(data).c_str()),width, version,eclevel);
	}
	else if (strcmp(deviceType.c_str(), "YK") == 0) {
		//�п�T80GESU�汾Ŀǰ��֧�֣��践����������
// 		int type = body_["type"].asInt();
// 		int charNum = body_["charNum"].asInt();
// 		ykPrinter_.GfPrint2DCode(type, (unsigned char*)data.c_str(), data.length());
		std::error_code ec;
		ec = std::make_error_code(std::errc::not_supported);
		throw std::system_error(ec,"�п�T80GESU�汾Ŀǰ��֧�֣��践����������");
	}
	body_.clear();
}

void PrinterDevice::PtrCutPaper() {
	std::string deviceType = head_["deviceType"].asString();
	if (strcmp(deviceType.c_str(), "FK") == 0)	{
		int distance = body_["distance"].asInt();
		fkPrinter_.POSFeedAndCut(distance);
	}
	else if (strcmp(deviceType.c_str(), "YK") == 0) {
		int type = body_["type"].asInt();
		ykPrinter_.GfCutPaper(type);
	}
	body_.clear();
}

void PrinterDevice::SetAlign() {
	std::string deviceType = head_["deviceType"].asString();
	int align = body_["align"].asInt();
	if (strcmp(deviceType.c_str(), "FK") == 0)	{
		fkPrinter_.POSSetAlign(align);
	}
	else if (strcmp(deviceType.c_str(), "YK") == 0) {
		ykPrinter_.YkPtrSetAlign(align);
	}
	body_.clear();
}

void PrinterDevice::FeedLine() {
	std::string deviceType = head_["deviceType"].asString();
	if (strcmp(deviceType.c_str(), "FK") == 0)	{
		fkPrinter_.POSFeedLine();
	}
	else if (strcmp(deviceType.c_str(), "YK") == 0) {
		ykPrinter_.GfPOS_FeedLine();
	}
	body_.clear();
}

void PrinterDevice::SetLeftDistance() {
	std::string deviceType = head_["deviceType"].asString();
	int distance = body_["distance"].asInt();
	if (strcmp(deviceType.c_str(), "FK") == 0)	{
		fkPrinter_.POSSetRightSpacing(3);
	}
	else if (strcmp(deviceType.c_str(), "YK") == 0) {
		ykPrinter_.GfSetLeftDistance(distance);
	}
	body_.clear();
}


BOOL PrinterDevice::IsJsonCheck() {
	try {
		if (!root_.isObject())	{
			throw 0;
		}
		CHECKJSONOBJECT("head", root_, "object");
		CHECKJSONOBJECT("body", root_, "object");
		CHECKJSONSTRING("device", root_["head"], "string");
		if (root_["head"]["device"].asString().empty())	{
			UnknownCmd("unkonwn", "-204", "json ��������[device] is empty");
			return FALSE;
		}
		CHECKJSONSTRING("deviceType", root_["head"], "string");
		if (root_["head"]["deviceType"].asString().empty())	{
			UnknownCmd("unkonwn", "-204", "json ��������[deviceType] is empty");
			return FALSE;
		}
		CHECKJSONSTRING("code", root_["head"], "string");
		if (root_["head"]["code"].asString().empty())	{
			UnknownCmd("unkonwn", "-204", "json ��������[code] is empty");
			return FALSE;
		}
	}	catch (ProcessException &e) {
		value_ = "-204";
		message_ = "json ��������,";
		message_ = message_ + e.what();
		UnknownCmd("unkonwn", "-204", message_);
		return FALSE;
	}	catch (int &value) {
		UnknownCmd("unkonwn", "-204", "json ��ʽ����");
		return FALSE;
	}
	catch (...) {
		UnknownCmd("unkonwn", "-204", "json δ֪����");
		return FALSE;
	}
	return TRUE;
}

void PrinterDevice::ResetJson(std::string error, std::string message) {
	head_["errCode"] = error;
	head_["msg"] = message;
	root_["head"] = head_;
	root_["body"] = body_;
}

void PrinterDevice::UnknownCmd(std::string code, std::string error_code, std::string msg) {
	root_ = Json::Value();
	root_.clear();
	head_.clear();
	body_.clear();
	head_["device"] = "printer";
	head_["deviceType"] = "0";
	head_["code"] = code;
	ResetJson(error_code, msg);
}

void PrinterDevice::PrinterFunction(std::string &code) {
	root_.clear();
	value_ = "0";
	message_ = "succ";
	std::string err = "-1";
	try {
		if (strcmp("open", code.c_str()) == 0)	{
			Open();
		}	else if (strcmp("close", code.c_str()) == 0)	{
			Close();
		}	else if (strcmp("online", code.c_str()) == 0)	{
			IsOnline();
		}	else if (strcmp("printStr", code.c_str()) == 0)	{
			PtrPrintStr();
		}	else if (strcmp("printPic", code.c_str()) == 0)	{
			PtrPrintPicture();
		}	else if (strcmp("printBarcode", code.c_str()) == 0)	{
			PtrPrintBarcode();
		}	else if (strcmp("printQR", code.c_str()) == 0)	{
			PtrPrintQR();
		}	else if (strcmp("cutPaper", code.c_str()) == 0)	{
			PtrCutPaper();
		}	else if (strcmp("setAlign", code.c_str()) == 0)	{
			SetAlign();
		}	else if (strcmp("feedLine", code.c_str()) == 0)	{
			FeedLine();
		}	else {
			UnknownCmd("unknown","-204","��֧�ֵĲ���");
			return;
		}
	}	catch (std::system_error &e) {
		value_ = ErrCodeConver(e.code().value());
		message_ = e.what();
		body_.clear();
	}	catch (int &value)	{
		if (value == FK_FAIL_ || value == YK_FAIL_)	{
			value_ = err;
			message_ = "fail";
		}
		else	if (value == FK_UNKNOWN_){
			value_ = err;
			message_ = "��֧�ִ˲���";
		}
		body_.clear();
	}	catch (...) {
		value_ = "-204";
		message_ = "fail";
		body_.clear();
	}
	ResetJson(value_, message_);
}


#if 0
void PrinterDevice::FkDevice(std::string &code) {
#pragma region self_pay 
	if (strcmp("open", code.c_str()) == 0)	{
		Open();
	}
	else if (strcmp("close", code.c_str()) == 0)	{
		Close();
	}
	else if (strcmp("online", code.c_str()) == 0)	{
		IsOnline();
	}
	else if (strcmp("printString", code.c_str()) == 0)	{
		std::string strData = body_["string"].asString();
		PrintRawData(strData);
	}
	else if (strcmp("printWstring", code.c_str()) == 0)	{
		std::wstring strData = helper::string_to_wstring(body_["wstring"].asString());
		PrintRawData(strData);
	}
	else if (strcmp("printUnionPaySign", code.c_str()) == 0)	{
		std::wstring union_pay_data_f = helper::string_to_wstring(body_["dataF"].asString());
		std::wstring union_pay_data_l = helper::string_to_wstring(body_["dataL"].asString());
		std::wstring sign_data = helper::string_to_wstring(body_["sign"].asString());
		PrintUnionData(union_pay_data_f, union_pay_data_l, sign_data);
	}
	else if (strcmp("printUnionPay", code.c_str()) == 0)	{
		std::wstring union_pay_data_f = helper::string_to_wstring(body_["dataF"].asString());
		std::wstring union_pay_data_l = helper::string_to_wstring(body_["dataL"].asString());
		PrintUnionData(union_pay_data_f, union_pay_data_l);
	}
#pragma endregion 


	else {
		UnknownCmd("unknown", "-204", "��֧�ֵĲ���");
	}
}

void PrinterDevice::YkDevice(std::string &code) {
#pragma region self_pay 
	if (strcmp("open", code.c_str()) == 0)	{
		Open();
	}
	else if (strcmp("close", code.c_str()) == 0)	{
		Close();
	}
	else if (strcmp("online", code.c_str()) == 0)	{
		IsOnline();
	}
	else if (strcmp("printString", code.c_str()) == 0)	{
		std::string strData = body_["string"].asString();
		PrintRawData(strData);
	}
	else if (strcmp("printWstring", code.c_str()) == 0)	{
		std::wstring strData = helper::string_to_wstring(body_["wstring"].asString());
		PrintRawData(strData);
	}
	else if (strcmp("printUnionPaySign", code.c_str()) == 0)	{
		std::wstring union_pay_data_f = helper::string_to_wstring(body_["dataF"].asString());
		std::wstring union_pay_data_l = helper::string_to_wstring(body_["dataL"].asString());
		std::wstring sign_data = helper::string_to_wstring(body_["sign"].asString());
		PrintUnionData(union_pay_data_f, union_pay_data_l, sign_data);
	}
	else if (strcmp("printUnionPay", code.c_str()) == 0)	{
		std::wstring union_pay_data_f = helper::string_to_wstring(body_["dataF"].asString());
		std::wstring union_pay_data_l = helper::string_to_wstring(body_["dataL"].asString());
		PrintUnionData(union_pay_data_f, union_pay_data_l);
	}
#pragma endregion 

	//����Ϊ��ӡ��dll�ӿ�
	std::string err = "-1";
	root_.clear();
	try	{
		if (strcmp(code.c_str(), "OpenUSBDeviceBySerial") == 0)	{
			ykPrinter_.YkPtrOpenUSBDeviceBySerial((char*)body_["serial"].asString().c_str());
		}
		else if (strcmp(code.c_str(), "EnumUSBDeviceSerials") == 0)	{
			char serials[10][20] = { 0 };
			ykPrinter_.YkPtrEnumUSBDeviceSerials(serials);
			body_.clear();
			body_["serials"] = Json::arrayValue;
			for (int i = 0; i < 10; i++)	{
				body_["serials"][i] = serials[i];
			}
		}
		else if (strcmp(code.c_str(), "OpenUsbPrtByName") == 0)	{
			TCHAR szOut[10] = { 0 };
			int size = MultiByteToWideChar(CP_ACP, 0, body_["usbName"].asString().c_str(), -1, szOut,
				strlen(body_["usbName"].asString().c_str()));
			HANDLE handle = ykPrinter_.YkPtrOpenUsbPrtByName(szOut);
			if (handle < 0)	{
				throw YK_FAIL_;
			}
			body_.clear();
			body_["handle"] = (int)handle;
		}
		else if (strcmp(code.c_str(), "OpenDevice") == 0)	{
			ykPrinter_.YkPtrOpenDevice(body_["port"].asInt(), body_["baud"].asInt());
		}
		else if (strcmp(code.c_str(), "CloseDevice") == 0)	{
			ykPrinter_.YkPtrCloseDevice();
		}
		else if (strcmp(code.c_str(), "GetDeviceHandle") == 0)	{
			int handle = ykPrinter_.YkPtrGetDeviceHandle();
			if (handle < 0)	{
				throw YK_FAIL_;
			}
			body_.clear();
			body_["handle"] = handle;
		}
		else if (strcmp(code.c_str(), "IsConnected") == 0)	{
			body_.clear();
			if (ykPrinter_.YkPtrIsConnected() > 0)
				body_["connect"] = "yes";
			else
				body_["connect"] = "no";
			return;
		}
		else if (strcmp(code.c_str(), "InitPrinter") == 0)	{
			ykPrinter_.YkPtrInitPrinter();
		}
		else if (strcmp(code.c_str(), "PrintStr") == 0)	{
			ykPrinter_.YkPtrPrintStr((char*)body_["string"].asString().c_str());
		}
		else if (strcmp(code.c_str(), "Enter") == 0)	{
			ykPrinter_.YkPtrEnter();
		}
		else if (strcmp(code.c_str(), "FeedPaper") == 0)	{
			ykPrinter_.YkPtrFeedPaper();
		}
		else if (strcmp(code.c_str(), "CancelPrintInPM") == 0)	{
			ykPrinter_.YkPtrCancelPrintInPM();
		}
		else if (strcmp(code.c_str(), "CancelPrintInPM") == 0)	{
			ykPrinter_.YkPtrResponse(body_["response"].asInt());
		}
		else if (strcmp(code.c_str(), "TabMove") == 0)	{
			ykPrinter_.YkPtrTabMove();
		}
		else if (strcmp(code.c_str(), "PrintInPM") == 0)	{
			ykPrinter_.YkPtrPrintInPM();
		}
		else if (strcmp(code.c_str(), "SetCharRightSpace") == 0)	{
			ykPrinter_.YkPtrSetCharRightSpace(body_["space"].asInt());
		}
		else if (strcmp(code.c_str(), "SetFontStyle") == 0)	{
			ykPrinter_.YkPtrSetFontStyle(body_["style"].asInt());
		}
		else if (strcmp(code.c_str(), "SetAbsPrnPos") == 0)	{
			ykPrinter_.YkPtrSetAbsPrnPos(body_["length"].asInt(), body_["height"].asInt());
		}
		else if (strcmp(code.c_str(), "EnableUserDefineChar") == 0)	{
			ykPrinter_.YkPtrEnableUserDefineChar(body_["char"].asInt());
		}
		else if (strcmp(code.c_str(), "SetUserDefineChar") == 0)	{
			ykPrinter_.YkPtrSetUserDefineChar(body_["start"].asInt(), body_["end"].asInt(),
				body_["width"].asInt(), (unsigned char*)body_["char"].asString().c_str());
		}
		else if (strcmp(code.c_str(), "EnableUnderLine") == 0)	{
			ykPrinter_.YkPtrEnableUnderLine(body_["enble"].asInt());
		}
		else if (strcmp(code.c_str(), "SetDefaultLineSpace") == 0)	{
			ykPrinter_.YkPtrSetDefaultLineSpace();
		}
		else if (strcmp(code.c_str(), "SetLineSpace") == 0)	{
			ykPrinter_.YkPtrSetLineSpace(body_["space"].asFloat());
		}
		else if (strcmp(code.c_str(), "CancelUserDefChar") == 0)	{
			ykPrinter_.YkPtrCancelUserDefChar(body_["char"].asInt());
		}
		else if (strcmp(code.c_str(), "SetTabPos") == 0)	{
			ykPrinter_.YkPtrSetTabPos((char*)body_["string"].asString().c_str());
		}
		else if (strcmp(code.c_str(), "SetEmphasized") == 0)	{
			ykPrinter_.YkPtrSetEmphasized(body_["able"].asInt());
		}
		else if (strcmp(code.c_str(), "Overlap") == 0)	{
			ykPrinter_.YkPtrOverlap(body_["able"].asInt());
		}
		else if (strcmp(code.c_str(), "EnablePM") == 0)	{
			ykPrinter_.YkPtrEnablePM();
		}
		else if (strcmp(code.c_str(), "SelectFont") == 0)	{
			ykPrinter_.YkPtrSelectFont(body_["type"].asInt());
		}
		else if (strcmp(code.c_str(), "SetInterCharSet") == 0)	{
			ykPrinter_.YkPtrSetInterCharSet(body_["index"].asInt());
		}
		else if (strcmp(code.c_str(), "EnterSM") == 0)	{
			ykPrinter_.YkPtrEnterSM();
		}
		else if (strcmp(code.c_str(), "SetDirectionInPM") == 0)	{
			ykPrinter_.YkPtrSetDirectionInPM(body_["direction"].asInt());
		}
		else if (strcmp(code.c_str(), "ClockwiseD90") == 0)	{
			ykPrinter_.YkPtrClockwiseD90(body_["able"].asInt());
		}
		else if (strcmp(code.c_str(), "SetPrnAreaInPM") == 0)	{
			ykPrinter_.YkPtrSetPrnAreaInPM(body_["left"].asInt(), body_["top"].asInt(),
				body_["width"].asInt(), body_["height"].asInt());
		}
		else if (strcmp(code.c_str(), "SetRelPrnPos") == 0)	{
			ykPrinter_.YkPtrSetRelPrnPos(body_["length"].asInt(), body_["height"].asInt());
		}
		else if (strcmp(code.c_str(), "SetAlign") == 0)	{
			ykPrinter_.YkPtrSetAlign(body_["type"].asInt());
		}
		else if (strcmp(code.c_str(), "SetPaperSensor") == 0)	{
			ykPrinter_.YkPtrSetPaperSensor(body_["sensor"].asInt());
		}
		else if (strcmp(code.c_str(), "SetSensorToStopPrint") == 0)	{
			ykPrinter_.YkPtrSetSensorToStopPrint(body_["index"].asInt());
		}
		else if (strcmp(code.c_str(), "EnablePanelButton") == 0)	{
			ykPrinter_.YkPtrEnablePanelButton(body_["able"].asInt());
		}
		else if (strcmp(code.c_str(), "PrnAndFeedLine") == 0)	{
			ykPrinter_.YkPtrPrnAndFeedLine(body_["line"].asInt());
		}
		else if (strcmp(code.c_str(), "SetCharCodeTable") == 0)	{
			ykPrinter_.YkPtrSetCharCodeTable(body_["table"].asInt());
		}
		else if (strcmp(code.c_str(), "FeedToStartPos") == 0)	{
			ykPrinter_.YkPtrFeedToStartPos();
		}
		else if (strcmp(code.c_str(), "SetCharSize") == 0)	{
			ykPrinter_.YkPtrSetCharSize(body_["hSize"].asInt(), body_["vSize"].asInt());
		}
		else if (strcmp(code.c_str(), "SetAbsVertPosInPM") == 0)	{
			ykPrinter_.YkPtrSetAbsVertPosInPM(body_["length"].asInt(), body_["height"].asInt());
		}
		else if (strcmp(code.c_str(), "DoTestPrint") == 0)	{
			ykPrinter_.YkPtrDoTestPrint(body_["n"].asInt(), body_["m"].asInt());
		}
		else if (strcmp(code.c_str(), "UserDefCmd") == 0)	{
			ykPrinter_.YkPtrUserDefCmd(body_["type"].asInt());
		}
		else if (strcmp(code.c_str(), "SetMemorySwitch") == 0)	{
			int array[8] = { 0 };
			for (int i = 0; i < body_["switch"].size(); i++)	{
				array[i] = body_["switch"][i].asInt();
			}
			ykPrinter_.YkPtrSetMemorySwitch(body_["index"].asInt(), array);
		}
		else if (strcmp(code.c_str(), "GetMemorySwitch") == 0)	{
			unsigned char array[8] = { 0 };
			ykPrinter_.YkPtrGetMemorySwitch(body_["index"].asInt(), array);
			body_.clear();
			for (int i = 0; i < 8; i++)	{
				body_["switch"][i] = (int)array[i];
			}
		}
		else if (strcmp(code.c_str(), "SetBlackMarkParam") == 0)	{
			ykPrinter_.YkPtrSetBlackMarkParam(body_["start"].asInt(), body_["direction"].asInt(),
				body_["length"].asInt(), body_["height"].asInt());
		}
		else if (strcmp(code.c_str(), "PrnAndBackToStd") == 0)	{
			ykPrinter_.YkPtrPrnAndBackToStd();
		}
		else if (strcmp(code.c_str(), "EnableUnderLine") == 0)	{
			ykPrinter_.YkPtrDefineControl(body_["function"].asInt(), body_["data"].asInt());
		}
		else if (strcmp(code.c_str(), "SetHRIPos") == 0)	{
			ykPrinter_.YkPtrSetHRIPos(body_["position"].asInt());
		}
		else if (strcmp(code.c_str(), "GetPrinterID") == 0)	{
			ykPrinter_.YkPtrGetPrinterID(body_["id"].asInt());
		}
		else if (strcmp(code.c_str(), "SetLeftMargin") == 0)	{
			ykPrinter_.YkPtrSetLeftMargin(body_["length"].asInt(), body_["height"].asInt());
		}
		else if (strcmp(code.c_str(), "ToLineHome") == 0)	{
			ykPrinter_.YkPtrToLineHome(body_["position"].asInt());
		}
		else if (strcmp(code.c_str(), "CutPaper") == 0)	{
			ykPrinter_.YkPtrCutPaper(body_["m"].asInt(), body_["n"].asInt());
		}
		else if (strcmp(code.c_str(), "SetPrnAreaWidth") == 0)	{
			ykPrinter_.YkPtrSetPrnAreaWidth(body_["length"].asInt(), body_["height"].asInt());
		}
		else if (strcmp(code.c_str(), "SetRelVertPosInPM") == 0)	{
			ykPrinter_.YkPtrSetRelVertPosInPM(body_["length"].asInt(), body_["height"].asInt());
		}
		else if (strcmp(code.c_str(), "EnableASB") == 0)	{
			ykPrinter_.YkPtrEnableASB(body_["able"].asInt());
		}
		else if (strcmp(code.c_str(), "EnableSmoothPrn") == 0)	{
			ykPrinter_.YkPtrEnableSmoothPrn(body_["able"].asInt());
		}
		else if (strcmp(code.c_str(), "SetHRICharStyle") == 0)	{
			ykPrinter_.YkPtrSetHRICharStyle(body_["type"].asInt());
		}
		else if (strcmp(code.c_str(), "SetBarCodeHeight") == 0)	{
			ykPrinter_.YkPtrSetBarCodeHeight(body_["height"].asFloat());
		}
		else if (strcmp(code.c_str(), "ClockwiseD90") == 0)	{
			ykPrinter_.YkPtrPrintBarCode(body_["type"].asInt(), body_["size"].asInt(),
				(char*)body_["barcode"].asString().c_str());
		}
		else if (strcmp(code.c_str(), "GetStatus") == 0)	{
			unsigned char n = 0;
			ykPrinter_.YkPtrGetStatus(n);
		}
		else if (strcmp(code.c_str(), "GetPrinterStatus") == 0)	{
			unsigned char n = 0;
			ykPrinter_.YkPtrGetPrinterStatus(n);
		}
		else if (strcmp(code.c_str(), "SetAlign") == 0)	{
			ykPrinter_.YkPtrSetBarCodeWidth(body_["width"].asFloat());
		}
		else if (strcmp(code.c_str(), "SetChineseFontStyle") == 0)	{
			ykPrinter_.YkPtrSetChineseFontStyle(body_["type"].asInt());
		}
		else if (strcmp(code.c_str(), "EnableChineseMode") == 0)	{
			ykPrinter_.YkPtrEnableChineseMode();
		}
		else if (strcmp(code.c_str(), "DisableChineseMode") == 0)	{
			ykPrinter_.YkPtrDisableChineseMode();
		}
		else if (strcmp(code.c_str(), "EnableChineseUnderLine") == 0)	{
			ykPrinter_.YkPtrEnableChineseUnderLine(body_["able"].asInt());
		}
		else if (strcmp(code.c_str(), "SetUserDefChinese") == 0)	{
			int code_array[72] = { 0 };
			for (int i = 0; i < body_["end"].size(); i++)	{
				code_array[i] = body_["codeArray"][i].asInt();
			}
			ykPrinter_.YkPtrSetUserDefChinese(body_["start"].asInt(), body_["end"].asInt(), code_array);
		}
		else if (strcmp(code.c_str(), "SetUserDefChineseArea") == 0)	{
			ykPrinter_.YkPtrSetUserDefChineseArea(body_["def"].asInt());
		}
		else if (strcmp(code.c_str(), "SetChineseLeftRightSpace") == 0)	{
			ykPrinter_.YkPtrSetChineseLeftRightSpace(body_["left"].asInt(), body_["right"].asInt());
		}
		else if (strcmp(code.c_str(), "SetChinese4TimesSize") == 0)	{
			ykPrinter_.YkPtrSetChinese4TimesSize(body_["able"].asInt());
		}
		else if (strcmp(code.c_str(), "EnableUpsidedown") == 0)	{
			ykPrinter_.YkPtrEnableUpsidedown(body_["able"].asInt());
		}
		else if (strcmp(code.c_str(), "PrintDefineBitmap") == 0)	{
			ykPrinter_.YkPtrPrintDefineBitmap(body_["m"].asInt(), body_["n"].asInt());
		}
		else if (strcmp(code.c_str(), "rDefineBitmap") == 0)	{
			ykPrinter_.YkPtrDefineBitmap((char*)body_["path"].asString().c_str());
		}
		else if (strcmp(code.c_str(), "PrintBitmap") == 0)	{
			ykPrinter_.YkPtrPrintBitmap((char*)body_["path"].asString().c_str(), body_["m"].asInt());
		}
		else if (strcmp(code.c_str(), "DownloadBitmapAndPrint") == 0)	{
			ykPrinter_.YkPtrDownloadBitmapAndPrint((char*)body_["path"].asString().c_str(), body_["m"].asInt());
		}
		else if (strcmp(code.c_str(), "SetUserDefineChar") == 0)	{
			ykPrinter_.YkPtrSetCashBoxDriveMode(body_["m"].asInt(), body_["t1"].asInt(),
				body_["t2"].asInt());
		}
		else if (strcmp(code.c_str(), "SetCallBack") == 0)	{
			ykPrinter_.YkPtrSetCallBack(NULL);//############## ����  ##############
		}
		else if (strcmp(code.c_str(), "EnableCallBack") == 0)	{
			ykPrinter_.YkPtrEnableCallBack(body_["able"].asInt());
		}
		else if (strcmp(code.c_str(), "DirectIO") == 0)	{
			unsigned char *data = (unsigned char *)body_["data"].asString().c_str();
			ykPrinter_.YkPtrDirectIO(data, strlen((char*)data));
		}
		else if (strcmp(code.c_str(), "WriteSerialNo") == 0)	{
			ykPrinter_.YkPtrWriteSerialNo((char*)body_["data"].asString().c_str());
		}
		else if (strcmp(code.c_str(), "ReadSerialNo") == 0)	{
			char data[256] = { 0 };
			ykPrinter_.YkPtrReadSerialNo(data);
			body_.clear();
			body_["data"] = data;
		}
		else if (strcmp(code.c_str(), "PrintRasterBmp") == 0)	{
			ykPrinter_.YkPtrPrintRasterBmp((char*)body_["data"].asString().c_str());
		}
		else if (strcmp(code.c_str(), "GetState") == 0)	{
			ykPrinter_.YkPtrGetState(); //############### δ֪
		}



		/*
		else if (strcmp(code.c_str(), "SetPrintFont") == 0)	{
		ykPrinter_.GfSetPrintFont();
		}
		else if (strcmp(code.c_str(), "SelectFont") == 0)	{
		ykPrinter_.YkPtrSelectFont(body_["type"].asInt());
		}
		else if (strcmp(code.c_str(), "SetInterCharSet") == 0)	{
		ykPrinter_.YkPtrSetInterCharSet(body_["index"].asInt());
		}
		else if (strcmp(code.c_str(), "EnterSM") == 0)	{
		ykPrinter_.YkPtrEnterSM();
		}
		else if (strcmp(code.c_str(), "SetDirectionInPM") == 0)	{
		ykPrinter_.YkPtrSetDirectionInPM(body_["direction"].asInt());
		}
		else if (strcmp(code.c_str(), "ClockwiseD90") == 0)	{
		ykPrinter_.YkPtrClockwiseD90(body_["able"].asInt());
		}
		else if (strcmp(code.c_str(), "SetPrnAreaInPM") == 0)	{
		ykPrinter_.YkPtrSetPrnAreaInPM(body_["left"].asInt(), body_["top"].asInt(),
		body_["width"].asInt(), body_["height"].asInt());
		}
		else if (strcmp(code.c_str(), "SetRelPrnPos") == 0)	{
		ykPrinter_.YkPtrSetRelPrnPos(body_["length"].asInt(), body_["height"].asInt());
		}
		else if (strcmp(code.c_str(), "SetAlign") == 0)	{
		ykPrinter_.YkPtrSetAlign(body_["type"].asInt());
		}
		else if (strcmp(code.c_str(), "SetPaperSensor") == 0)	{
		ykPrinter_.YkPtrSetPaperSensor(body_["sensor"].asInt());
		}
		else if (strcmp(code.c_str(), "SetSensorToStopPrint") == 0)	{
		ykPrinter_.YkPtrSetSensorToStopPrint(body_["index"].asInt());
		}
		else if (strcmp(code.c_str(), "EnablePanelButton") == 0)	{
		ykPrinter_.YkPtrEnablePanelButton(body_["able"].asInt());
		}
		else if (strcmp(code.c_str(), "PrnAndFeedLine") == 0)	{
		ykPrinter_.YkPtrPrnAndFeedLine(body_["line"].asInt());
		}
		else if (strcmp(code.c_str(), "SetCharCodeTable") == 0)	{
		ykPrinter_.YkPtrSetCharCodeTable(body_["table"].asInt());
		}
		else if (strcmp(code.c_str(), "FeedToStartPos") == 0)	{
		ykPrinter_.YkPtrFeedToStartPos();
		}
		else if (strcmp(code.c_str(), "SetCharSize") == 0)	{
		ykPrinter_.YkPtrSetCharSize(body_["hSize"].asInt(), body_["vSize"].asInt());
		}
		else if (strcmp(code.c_str(), "SetAbsVertPosInPM") == 0)	{
		ykPrinter_.YkPtrSetAbsVertPosInPM(body_["length"].asInt(), body_["height"].asInt());
		}
		else if (strcmp(code.c_str(), "DoTestPrint") == 0)	{
		ykPrinter_.YkPtrDoTestPrint(body_["n"].asInt(), body_["m"].asInt());
		}
		else if (strcmp(code.c_str(), "UserDefCmd") == 0)	{
		ykPrinter_.YkPtrUserDefCmd(body_["type"].asInt());
		}
		else if (strcmp(code.c_str(), "SetMemorySwitch") == 0)	{
		int array[8] = { 0 };
		for (int i = 0; i < body_["switch"].size(); i++)	{
		array[i] = body_["switch"][i].asInt();
		}
		ykPrinter_.YkPtrSetMemorySwitch(body_["index"].asInt(), array);
		}
		else if (strcmp(code.c_str(), "GetMemorySwitch") == 0)	{
		unsigned char array[8] = { 0 };
		ykPrinter_.YkPtrGetMemorySwitch(body_["index"].asInt(), array);
		body_.clear();
		for (int i = 0; i < 8; i++)	{
		body_["switch"][i] = (int)array[i];
		}
		}
		else if (strcmp(code.c_str(), "SetBlackMarkParam") == 0)	{
		ykPrinter_.YkPtrSetBlackMarkParam(body_["start"].asInt(), body_["direction"].asInt(),
		body_["length"].asInt(), body_["height"].asInt());
		}
		else if (strcmp(code.c_str(), "PrnAndBackToStd") == 0)	{
		ykPrinter_.YkPtrPrnAndBackToStd();
		}
		else if (strcmp(code.c_str(), "EnableUnderLine") == 0)	{
		ykPrinter_.YkPtrDefineControl(body_["function"].asInt(), body_["data"].asInt());
		}
		else if (strcmp(code.c_str(), "SetHRIPos") == 0)	{
		ykPrinter_.YkPtrSetHRIPos(body_["position"].asInt());
		}
		else if (strcmp(code.c_str(), "GetPrinterID") == 0)	{
		ykPrinter_.YkPtrGetPrinterID(body_["id"].asInt());
		}
		else if (strcmp(code.c_str(), "SetLeftMargin") == 0)	{
		ykPrinter_.YkPtrSetLeftMargin(body_["length"].asInt(), body_["height"].asInt());
		}
		else if (strcmp(code.c_str(), "ToLineHome") == 0)	{
		ykPrinter_.YkPtrToLineHome(body_["position"].asInt());
		}
		else if (strcmp(code.c_str(), "CutPaper") == 0)	{
		ykPrinter_.YkPtrCutPaper(body_["m"].asInt(), body_["n"].asInt());
		}
		else if (strcmp(code.c_str(), "SetPrnAreaWidth") == 0)	{
		ykPrinter_.YkPtrSetPrnAreaWidth(body_["length"].asInt(), body_["height"].asInt());
		}
		else if (strcmp(code.c_str(), "SetRelVertPosInPM") == 0)	{
		ykPrinter_.YkPtrSetRelVertPosInPM(body_["length"].asInt(), body_["height"].asInt());
		}
		else if (strcmp(code.c_str(), "EnableASB") == 0)	{
		ykPrinter_.YkPtrEnableASB(body_["able"].asInt());
		}
		else if (strcmp(code.c_str(), "EnableSmoothPrn") == 0)	{
		ykPrinter_.YkPtrEnableSmoothPrn(body_["able"].asInt());
		}
		else if (strcmp(code.c_str(), "SetHRICharStyle") == 0)	{
		ykPrinter_.YkPtrSetHRICharStyle(body_["type"].asInt());
		}
		else if (strcmp(code.c_str(), "SetBarCodeHeight") == 0)	{
		ykPrinter_.YkPtrSetBarCodeHeight(body_["height"].asFloat());
		}
		else if (strcmp(code.c_str(), "ClockwiseD90") == 0)	{
		ykPrinter_.YkPtrPrintBarCode(body_["type"].asInt(), body_["size"].asInt(),
		(char*)body_["barcode"].asString().c_str());
		}
		else if (strcmp(code.c_str(), "GetStatus") == 0)	{
		unsigned char n = 0;
		ykPrinter_.YkPtrGetStatus(n);
		}
		else if (strcmp(code.c_str(), "GetPrinterStatus") == 0)	{
		unsigned char n = 0;
		ykPrinter_.YkPtrGetPrinterStatus(n);
		}
		else if (strcmp(code.c_str(), "SetAlign") == 0)	{
		ykPrinter_.YkPtrSetBarCodeWidth(body_["width"].asFloat());
		}
		else if (strcmp(code.c_str(), "SetChineseFontStyle") == 0)	{
		ykPrinter_.YkPtrSetChineseFontStyle(body_["type"].asInt());
		}
		*/


	}
	catch (std::system_error &e) {
		value_ = ErrCodeConver(e.code().value());
		message_ = e.what();
		body_.clear();
	}
	catch (int &value)	{
		if (value == FK_FAIL_)	{
			value_ = err;
			message_ = "fail";
		}
		else	if (value == FK_UNKNOWN_){
			value_ = err;
			message_ = "��֧�ִ˲���";
		}
		body_.clear();
	}
	catch (...) {
		value_ = "-204";
		message_ = "fail";
		body_.clear();
	}
	ResetJson(value_, message_);
}
#endif