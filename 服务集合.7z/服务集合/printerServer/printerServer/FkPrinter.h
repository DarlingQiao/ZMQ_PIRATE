#ifndef __FK_PRINTER_H__
#define __FK_PRINTER_H__

#include <string>
#include <tchar.h>
#include "accuree/PrinterLibs.h"

#define FK_FAIL_ 12
#define FK_UNKNOWN_ 123




class FkPrinter
{
 public:
	FkPrinter();
	~FkPrinter();


#pragma region self_pay 
	//��������ģ��
	void OpenUsb();
	void CloseUsb();
	bool IsOnline();
	bool PrintRawData(const std::string& strData);
	bool PrintRawData(const std::wstring& strData);
	bool PrintRawData(const std::wstring& union_pay_data_f,
										const std::wstring& union_pay_data_l,
										const std::wstring& sign_data);
	bool PrintRawData(const std::wstring& union_pay_data_f,
										const std::wstring& union_pay_data_l);
#pragma endregion 

	
	//��̬��ӿ�
#pragma region Port
	void PortOpenCom(TCHAR * pName, DWORD dwBaudrate, DWORD dwParity);
	void PortOpenTcp(TCHAR * szIp, USHORT nPort);
	void PortOpenUsb(TCHAR * pName);
	void PortOpenLpt(TCHAR * pName);
	void PortOpenPrn(TCHAR * pName);
	void PortCloseCom();
	void PortCloseTcp();
	void PortCloseUsb();
	void PortCloseLpt();
	void PortClosePrn();
	void PortSetPort(DWORD dwPortType);

	void PortEnumCom(TCHAR * pBuf, int cbBuf, int * pcbNeeded, int * pcnReturned);
	void PortEnumLpt(TCHAR * pBuf, int cbBuf, int * pcbNeeded, int * pcnReturned);
	void PortEnumUSB(TCHAR * pBuf, int cbBuf, int * pcbNeeded, int * pcnReturned);
	void PortEnumPrn(TCHAR * pBuf, int cbBuf, int * pcbNeeded, int * pcnReturned);
#pragma endregion 

#pragma region Page
	void PAGEPageEnter();
	void PAGEPagePrint();
	void PAGEPageExit();
	void PAGESetPrintArea(int left, int top, int right, int bottom, int direction);
	void PAGEDrawString(TCHAR * pszString, int x, int y, int nWidthScale, int nHeightScale, int nFontType, int nFontStyle);
	void PAGEDrawRect(int x, int y, int nWidth, int nHeight, int nColor);
	void PAGEDrawBarcode(TCHAR * pszBarcodeContent, int x, int y, int nBarcodeUnitWidth, int nBarcodeHeight, int nHriFontType,									 int nHriFontPosition, int nBarcodeType);
	void PAGEDrawQRCode(TCHAR * pszContent, int x, int y, int nQRCodeUnitWidth, int nVersion, int nEcLevel);
	void PAGEDrawBitmap(TCHAR * FileName, int x, int y, int dwWidth, int dwHeight);
#pragma endregion

#pragma region Pos
	// ��ӡ
	// ��ӡ�ı�
	void POSTextOut(TCHAR * pszString, int x, int nWidthScale, int nHeightScale, int nFontType, int nFontStyle);
	// ��ӡ����
	void POSSetBarcode(TCHAR * pszBarcodeContent, int nBarcodeUnitWidth, int nBarcodeHeight, int nHriFontType, int nHriFontPosition, int nBarcodeType);
	//��ӡQR��
	void POSSetQRCode(TCHAR * pszContent, int nQRCodeUnitWidth, int nVersion, int nEcLevel);
	// ��ӡͼƬ
	void POSPrintPicture(TCHAR * FileName, DWORD dwWidth, DWORD dwHeight);
	// ��ӡ�Բ�ҳ
	void POSSelfTest();

	// ��ֽ
	void POSFeedLine();
	void POSFeedNLine(int nLine);
	void POSFeedNDot(int nDot);

	// ��ѯ
	// ��ѯ��ӡ��״̬
	void POSQuery(unsigned char status[1]);
	// ʵʱ��ѯ��ӡ��״̬
	void POSRTQuery(unsigned char status[4]);
	// ���ݴ�ӡ�����ѯ
	void POSTicketSucceed(int dwSendIndex);

	// ����
	void POSSetMotionUnit(int nHorizontal, int nVertical);
	// �����и�
	void POSSetLineHeight(int nDistance);
	// �����ַ��Ҽ��
	void POSSetRightSpacing(int nDistance);
	// ���ö���
	void POSSetAlign(int nAlign);

	// ����
	// ������λ
	void POSReset();
	// ��Ǯ��
	void POSKickOutDrawer(int nID, int nOnTimes, int nOffTimes);
	// ֱ����ֽ
	void POSCutPaper(int nMode);
	// ��ӡ����ֽ[ ��ӡλ�õ��е�֮����� + nDistance ���������ƶ���λ��]Ȼ����ֽ
	void POSFeedAndCut(int nDistance);
	// ���������� nBeepCount ���д��� nBeepMillis ÿ�����е�ʱ�� = 100 * nBeemMillis ms
	void POSBeep(int nBeepCount, int nBeepMillis);
#pragma endregion
};

#endif
