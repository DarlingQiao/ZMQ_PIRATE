
#ifndef _PRINTER_DEVICE_H_
#define _PRINTER_DEVICE_H_

#include <stdio.h>
#include <iostream>
#include <string>

#include "jsoncpp/json.h"
#include "zeromq/czmq.h"
#include "zeromq/zmq.h"
#include "FkPrinter.h"
#include "YkPrinter.h"

class PrinterDevice
{
 public:
	 PrinterDevice();
	 ~PrinterDevice();

 public:
	 std::string OutJson();
	 void ParseMessageCmd(zmsg_t *request);
	 void Open();
   void Close();
	 void IsOnline();
	 void PtrPrintStr();
	 void PtrPrintPicture();
	 void PtrPrintBarcode();
	 void PtrPrintQR();
	 void PtrCutPaper();
	 void SetAlign();
	 void FeedLine();
	 void SetLeftDistance();

 private:
	BOOL IsJsonCheck();
	void ResetJson(std::string error, std::string message);
	void UnknownCmd(std::string cmd, std::string error_code, std::string msg);
	void PrinterFunction(std::string &code);
	//void FkDevice(std::string &code);
	//void YkDevice(std::string &code);

 private:
  std::string value_;
  std::string message_;
  Json::Value root_;
  Json::FastWriter write_;
  Json::Value head_,body_;
	FkPrinter fkPrinter_;
	YkPrinter ykPrinter_;
};

#endif

