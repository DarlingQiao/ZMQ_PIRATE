#ifndef ACCUREE_DEFINE_HPP
#define ACCUREE_DEFINE_HPP

typedef unsigned char byte;
typedef unsigned short ushort;
typedef unsigned long ulong;

#endif
