#include "ScannerDevice.h"
#include <future>


NAME_MAP ctrlcode_map[UNKNOWN + 1] = {
    { OPEN, "open" },
    { CLOSE, "close" },
    { RESET, "reset" },
    { ENABLE, "enable" },
    { DISABLE, "disable" },
    { GET_BARCODE, "get_barcode" },
    { UNKNOWN, "unknow" }
};

ScannerDevice::ScannerDevice() {
  isOpen = false;
}


ScannerDevice::~ScannerDevice() {

}

void ScannerDevice::Open() {

  value_ = "0";
  message_ = "success";

  std::string device = body_["port"].asString();

  try{
    scanner_.open(device);
  }
  catch (std::system_error &e){
    value_ = e.code().value();
    message_ = e.code().message();
  }
  root_.clear();
  body_.clear();
  ResetJson(value_, message_);

  
}

void ScannerDevice::Reset() {

  value_ = "0";
  message_ = "success";
  try{
    scanner_.reset();
  }
  catch (std::system_error &e){
    value_ = e.code().value();
    message_ = e.code().message();
  }
  root_.clear();
  body_.clear();
  ResetJson(value_, message_);
}

void ScannerDevice::Close() {

  value_ = "0";
  message_ = "success";
  try{
    scanner_.close();
  }
  catch (std::system_error &e){
    value_ = e.code().value();
    message_ = e.code().message();
  }
  root_.clear();
  body_.clear();
  ResetJson(value_, message_);
  isOpen = false;
}

DWORD WINAPI PublishThread(LPVOID _this)
{
  ScannerDevice *this_ = (ScannerDevice *)_this;

  std::string value = "0";
  std::string message = "success";
  std::string barcode;
  std::error_code ec;

#if 1
	//��ȡ�����ļ�
	zconfig_t *obj = zconfig_load("config.cfg");
	if (obj == NULL)	{
		printf("û�ҵ������ļ�,����Ӧ�÷���exe�����ͬһ��Ŀ¼�£������ļ���Ϊ config.cfg");
		zmq_sleep(3);
		return 0;
	}
	char* filename = (char*)zconfig_filename(obj);
	/*# �����
	server
	reply = "tcp://localhost:5556"
	push = "tcp://localhost:5557"
	*/
	char *reply_push = zconfig_get(obj, "/server/push", "tcp://localhost:5558");
	std::string serverPort = reply_push;
	zconfig_destroy(&obj);
#endif

	_mdwrk_pub_t *session = server_pub_new((char*)serverPort.c_str());
//   while (true) {
//     server_pub_send(session, "scan", "===========");
//     Sleep(1000);
//   }
  Json::Value root;
  Json::FastWriter write;
  while (this_->isOpen)
  {
    try{
      barcode = this_->scanner_.get_barcode(ec);
    }
    catch (std::system_error &e){
      value = e.code().value();
      message = e.code().message();
      root.clear();
      root["head"]["device"] = "scan";
      root["head"]["deviceType"] = "0";
      root["head"]["code"] = "get_barcode";
      root["head"]["errCode"] = value;
      root["head"]["msg"] = message;
      root["body"] = Json::Value();

      server_pub_send(session, "scan", (char *)write.write(root).c_str());
    }
    if (!barcode.empty()) {
      root.clear();
      root["head"]["device"] = "scan";
      root["head"]["deviceType"] = "0";
      root["head"]["code"] = "get_barcode";
      root["head"]["errCode"] = value;
      root["head"]["msg"] = message;
      root["body"]["barcode"] = barcode;
			printf("barcode = %s \n",barcode.c_str());
      server_pub_send(session, "scan", (char *)write.write(root).c_str());
    }
  }
  return 0;
}

void ScannerDevice::GetBarcode() {

  CreateThread(NULL, 0, PublishThread, this, 0, NULL);
#if 0


  std::async(std::launch::async, [&]() {

    std::string value = "0";
    std::string message = "success";
    std::string barcode;
    std::error_code ec;

#if 1
    //��ȡ�����ļ�
    zconfig_t *obj = zconfig_load("config.cfg");
    if (obj == NULL) {
      printf("û�ҵ������ļ�,����Ӧ�÷���exe�����ͬһ��Ŀ¼�£������ļ���Ϊ config.cfg");
      zmq_sleep(3);
      return 0;
    }
    char* filename = (char*)zconfig_filename(obj);
    /*# �����
    server
    reply = "tcp://localhost:5556"
    push = "tcp://localhost:5557"
    */
    char *reply_push = zconfig_get(obj, "/server/push", "tcp://*:5558");
    std::string serverPort = reply_push;
    zconfig_destroy(&obj);
#endif

    _mdwrk_pub_t *session = server_pub_new((char*)serverPort.c_str());

    Json::Value root;
    Json::FastWriter write;
    while (isOpen) {
      try {
        barcode = scanner_.get_barcode(ec);
      } catch (std::system_error &e) {
        value = e.code().value();
        message = e.code().message();
        root.clear();
        root["head"]["device"] = "scan";
        root["head"]["deviceType"] = "0";
        root["head"]["code"] = "get_barcode";
        root["head"]["errCode"] = value;
        root["head"]["msg"] = message;
        root["body"] = Json::Value();

        server_pub_send(session, "scan", (char *)write.write(root).c_str());
      }
      if (!barcode.empty()) {
        root.clear();
        root["head"]["device"] = "scan";
        root["head"]["deviceType"] = "0";
        root["head"]["code"] = "get_barcode";
        root["head"]["errCode"] = value;
        root["head"]["msg"] = message;
        root["body"]["barcode"] = barcode;
        printf("barcode = %s \n", barcode.c_str());
        server_pub_send(session, "scan", (char *)write.write(root).c_str());
      }
    }
    return 0;
  });
#endif
}

void ScannerDevice::Enable() {

  value_ = "0";
  message_ = "success";
  try{
    scanner_.enable();
  }
  catch (std::system_error &e){
    value_ = e.code().value();
    message_ = e.code().message();
  }
  root_.clear();
  body_.clear();
  ResetJson(value_, message_);
  isOpen = true;
}

void ScannerDevice::Disable() {

  value_ = "0";
  message_ = "success";
  try{
    scanner_.disable();
  } catch (std::system_error &e){
    value_ = e.code().value();
    message_ = e.code().message();
  }
  root_.clear();
  body_.clear();
  ResetJson(value_, message_);
  isOpen = false;
}

void ScannerDevice::UnknownCmd(std::string code, std::string msg, std::string error_code) {

  root_.clear();
  head_.clear();
  body_.clear();
  head_["device"] = "scan";
  head_["deviceType"] = "0";
  head_["code"] = code;
  ResetJson(error_code, msg);

}

void ScannerDevice::ResetJson(std::string error, std::string message) {

  head_["errCode"] = error;
  head_["msg"] = message;
  root_["head"] = head_;
  root_["body"] = body_;
}

void ScannerDevice::ParseMessageCmd(zmsg_t *request) {

  if (request == NULL) {
    return;
  }
  Json::Reader read;

  zframe_t *data = zmsg_last(request);
  char *str = zframe_strdup(data);
  std::string buffer = str;
  free(str);
  str = nullptr;

  if (!read.parse(buffer, root_)) {
    UnknownCmd("unkonwn", "json ��������", "-204");
    return;
  }

  try {
    CHECKJSONOBJECT("head", root_, "object");
   // CHECKJSONOBJECT("body", root_, "object");
    CHECKJSONSTRING("device", root_["head"], "string");
    CHECKJSONSTRING("deviceType", root_["head"], "string");
    CHECKJSONSTRING("code", root_["head"], "string");
  }  catch (ProcessException &e) {
    UnknownCmd("unkonwn", "json ��������", "-204");
    return;
  }  catch (...) {
    UnknownCmd("unkonwn", "json δ֪����", "-204");
    return;
  }
  head_ = root_["head"];
  body_ = root_["body"];
  std::string cmd = head_["code"].asString();

  code_ = UNKNOWN;
  for (int i = 0; i < UNKNOWN; i++) {
    if (strncmp(cmd.c_str(), ctrlcode_map[i].str, strlen(ctrlcode_map[i].str)) == 0) {
      code_ = (CTRLCODE)ctrlcode_map[i].code;
      break;
    }
  }
  switch (code_) {
  case OPEN:
    Open(); break;
  case CLOSE:
    Close(); break;
  case RESET:
    Reset(); break;
  case ENABLE:
    Enable(); break;
  case DISABLE:
    Disable(); break;
  case GET_BARCODE:
    GetBarcode(); break;
  default:
    UnknownCmd(cmd, "û�ҵ�������", "-204"); return;
  }
}