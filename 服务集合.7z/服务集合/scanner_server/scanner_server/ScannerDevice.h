
#ifndef _SCANNER_DEVICE_H_
#define _SCANNER_DEVICE_H_

#include <stdio.h>
#include <iostream>
#include <string>

#include "jsoncpp\json.h"
#include "zeromq\czmq.h"
#include "zeromq\zmq.h"
#include "accuree\flatbed_scanner.h"
#include "mdp.h"
#include "exception.h"
#include "zmq_mdp_server.h"

//json
#define CHECKJSONINT(_NAME,_ROOT,_TYPE) \
	if(!(_ROOT).isMember((_NAME)))\
    {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
    }\
	if(!(_ROOT)[(_NAME)].isInt())\
    {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
    }

#define CHECKJSONSTRING(_NAME,_ROOT,_TYPE) \
	if(!(_ROOT).isMember((_NAME)))\
    {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
    }\
	if(!(_ROOT)[(_NAME)].isString())\
    {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
    }

#define CHECKJSONOBJECT(_NAME,_ROOT,_TYPE) \
	if(!(_ROOT).isMember((_NAME)))\
    {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
    }\
	if(!(_ROOT)[(_NAME)].isObject())\
    {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
    }

#define CHECKJSONARRAY(_NAME,_ROOT,_TYPE) \
	if(!(_ROOT).isMember((_NAME)))\
    {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
    }\
	if(!(_ROOT)[(_NAME)].isArray())\
    {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
    }

struct NAME_MAP {
  int code;
  char* str;
};

enum CTRLCODE {
  OPEN = 0,
  CLOSE,
  RESET,
  ENABLE,
  DISABLE,
  GET_BARCODE,
  UNKNOWN
};

static DWORD WINAPI  PublishThread(LPVOID _this);

class ScannerDevice
{
public:
  ScannerDevice();
  ~ScannerDevice();

public:
  void Open(Json::Value &root);
  void Reset(Json::Value &root);
  void Close(Json::Value &root);
	void GetBarcode(Json::Value &root);
  void Enable(Json::Value &root);
  void Disable(Json::Value &root);

  void Open();
  void Reset();
  void Close();
  void GetBarcode();
  void Enable();
  void Disable();
  void UnknownCmd(std::string cmd, std::string msg, std::string error_code);

  void ParseMessageCmd(zmsg_t *request);

  inline std::string OutJson() {
    return write_.write(root_);
  }
  bool isOpen;
  flatbed_scanner scanner_;
private:

  std::string value_;
  std::string message_;


  CTRLCODE code_;

  Json::Value root_;
  Json::FastWriter write_;
  Json::Value head_, body_;

  
  void ResetJson(std::string error, std::string message);
  std::string ParseJson();
};

#endif

