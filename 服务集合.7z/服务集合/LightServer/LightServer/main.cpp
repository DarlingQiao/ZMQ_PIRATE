#include "LightDevice.h"
#include "zmq_mdp_server.h"

#define PROXY_ADDR "tcp://localhost:5555"

int main(int argc, char* argv[]) {
	//��ȡ�����ļ�
	zconfig_t *root = zconfig_load("config.cfg");
	if (root == NULL)	{
		printf("û�ҵ������ļ�,����Ӧ�÷���exe�����ͬһ��Ŀ¼�£������ļ���Ϊ config.cfg");
		zmq_sleep(3);
		return -1;
	}
	char* filename = (char*)zconfig_filename(root);
	/*# �����
	server
		reply = "tcp://localhost:5556"
		push = "tcp://localhost:5557"
		*/
	char *reply_port = zconfig_get(root, "/server/reply", "tcp://*:5555");
	std::string serverPort = reply_port;
	zconfig_destroy(&root);
  LightDevice scanner_device;
	mdwrk_t *session = server_new((char*)serverPort.c_str(), "light");
	std::string str;
  while (true) {
    zmsg_t *request = server_recv(session);
    scanner_device.ParseMessageCmd(request);
		str = scanner_device.OutJson();
		message_set(request, str.c_str());
		printf("���ͻؿͻ��ˣ�buff = %s,len = %d \n", str.c_str(), strlen(str.c_str()));
    server_reply(session, &request);
  }
  server_destroy(&session);
  return 0;
}


