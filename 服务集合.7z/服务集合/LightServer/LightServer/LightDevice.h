
#ifndef _LIGHT_DEVICE_H_
#define _LIGHT_DEVICE_H_

#include <stdio.h>
#include <iostream>
#include <string>

#include "jsoncpp\json.h"
#include "zeromq\czmq.h"
#include "zeromq\zmq.h"
#include "accuree\light.h"
#include "accuree\light_status.hpp"
#include "mdp.h"
#include "exception.h"

//json�������궨��
#define CHECKJSONINT(_NAME,_ROOT,_TYPE) \
	if(!(_ROOT).isMember((_NAME)))\
  {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
  }\
	if(!(_ROOT)[(_NAME)].isInt())\
  {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
  }

#define CHECKJSONSTRING(_NAME,_ROOT,_TYPE) \
	if(!(_ROOT).isMember((_NAME)))\
  {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
  }\
	if(!(_ROOT)[(_NAME)].isString())\
  {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
  }

#define CHECKJSONOBJECT(_NAME,_ROOT,_TYPE) \
	if(!(_ROOT).isMember((_NAME)))\
  {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
  }\
	if(!(_ROOT)[(_NAME)].isObject())\
  {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
  }

#define CHECKJSONARRAY(_NAME,_ROOT,_TYPE) \
	if(!(_ROOT).isMember((_NAME)))\
  {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
  }\
	if(!(_ROOT)[(_NAME)].isArray())\
  {\
	THROW_A03_EXCEPTION((_NAME),(_TYPE));\
  }

std::string ErrCodeConver(int value);

/*
0��ȫ��
1���׵�
2�����
3���̵�
4���볮��
5��������
6��������̵�
7����������
8���������������
9������������
10������
*/

class LightDevice
{
 public:
	 LightDevice();
	 ~LightDevice();

 public:
	 std::string OutJson();

	 void ParseMessageCmd(zmsg_t *request);
   void Open();
   void Close();
	 void GetStatus();

	 void SetWhite();
	 void SetRed();
	 void SetGreen();
	 void SetCashIn();
	 void SetCashOut();
	 void SetEpp();
	 void SetCard();
	 void SetEppL();
	 void SetCashOutL();
	 void SetLockL();
	 void SetAll();



 private:
	BOOL IsJsonCheck();
	void ResetJson(std::string error, std::string message);
	void UnknownCmd(std::string cmd, std::string error_code, std::string msg);
	//std::string ParseJson();
	BOOL ActionLed();


 private:
  std::string value_;
  std::string message_;
  Json::Value root_;
  Json::FastWriter write_;
  Json::Value head_,body_;
	//CTRLCODE code_;
	light light_;
	led_state st;
};

#endif

