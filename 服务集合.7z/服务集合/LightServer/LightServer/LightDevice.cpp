#include "LightDevice.h"


LightDevice::LightDevice() {

}


LightDevice::~LightDevice() {

}

std::string LightDevice::OutJson() {
	return write_.write(root_);
}

void LightDevice::ParseMessageCmd(zmsg_t *request) {
	if (request == NULL) {
		return;
	}
	Json::Reader read;
	zframe_t *data = zmsg_last(request);
	char *str = zframe_strdup(data);
	std::string buffer = str;
	free(str);
	str = NULL;
	root_.clear();
	head_.clear();
	body_.clear();
	if (!read.parse(buffer, root_)) {
		UnknownCmd("unkonwn", "-204", "json ��������");
		return;
	}
	if (!IsJsonCheck())	{
		return;
	}
	head_ = root_["head"];
	body_ = root_["body"];
	std::string code = head_["code"].asString();
	std::string device = head_["device"].asString();
	std::string deviceType = head_["deviceType"].asString();

#if 0
	code_ = UNKNOWN;
	for (int i = 0; i < UNKNOWN; i++) {
		if (strncmp(code.c_str(), ctrlcode_map[i].str, strlen(ctrlcode_map[i].str)) == 0) {
			code_ = (CTRLCODE)ctrlcode_map[i].code;
			break;
		}
	}
	switch (code_) {
	case OPEN:
		Open(); break;
	case CLOSE:
		void Close(); break;
	case RESET:
		void Reset(); break;
	case ENABLE:
		void Enable(); break;
	case DISABLE:
		void Disable(); break;
	case GET_BARCODE:
		void GetBarcode(); break;
	default:
		UnknownCmd(cmd, "-204", "û�ҵ�code����֧�ֵĲ���"); return;
	}
#endif

	if (strcmp("open", code.c_str()) == 0)	{
		Open();
	}
	else if (strcmp("close", code.c_str()) == 0)	{
		Close();
	}
	else if (strcmp("status", code.c_str()) == 0)	{
		GetStatus();
	}
	else if (strcmp("setWhite", code.c_str()) == 0)	{
		SetWhite();
	}
	else if (strcmp("setRed", code.c_str()) == 0)	{
		SetRed();
	}
	else if (strcmp("setGreen", code.c_str()) == 0)	{
		SetGreen();
	}
	else if (strcmp("setCashIn", code.c_str()) == 0)	{
		SetCashIn();
	}
	else if (strcmp("setCashOut", code.c_str()) == 0)	{
		SetCashOut();
	}
	else if (strcmp("setEpp", code.c_str()) == 0)	{
		SetEpp();
	}
	else if (strcmp("setCard", code.c_str()) == 0)	{
		SetCard();
	}
	else if (strcmp("setEppL", code.c_str()) == 0)	{
		SetEppL();
	}
	else if (strcmp("setCashOutL", code.c_str()) == 0)	{
		SetCashOutL();
	}
	else if (strcmp("setLockl", code.c_str()) == 0)	{
		SetLockL();
	}
	else if (strcmp("setAll", code.c_str()) == 0)	{
		SetAll();
	}
	else {
		UnknownCmd("unknown", "-204", "��֧�ֵĲ���");
	}
}

void LightDevice::Open() {
  value_ = "0";
  message_ = "success";
  std::string devicePort = body_["port"].asString();
  try{
		if (devicePort.empty())	{
			throw 0;
		}
		light_.open(devicePort);
  } catch (std::system_error &e){
		value_ = ErrCodeConver(e.code().value());
    message_ = e.what();
	}	catch (int &value){
		value_ = "204";
		message_ = "json ��������[port]";
	}
  root_.clear();
  body_.clear();
  ResetJson(value_, message_);
}

void LightDevice::Close() {
	value_ = "0";
	message_ = "success";
	try{
		light_.close();
	}
	catch (std::system_error &e){
		value_ = ErrCodeConver(e.code().value());
		message_ = e.what();
	}
	root_.clear();
	body_.clear();
	ResetJson(value_, message_);
}

void LightDevice::GetStatus() {
	value_ = "0";
	message_ = "success";
	try	{
		light_status state;
		std::error_code ec;
		//state = light_.status();
		ec = light_.status(state, ec);
	}	catch (std::system_error &e)	{
		value_ = ErrCodeConver(e.code().value());
		message_ = e.what();
	}	catch (...)	{
		value_ = "-204";
		message_ = "δ֪����";
	}
	root_.clear();
	body_.clear();
	ResetJson(value_, message_);
}

// void LightDevice::SetLight() {
// 	std::string type = body_["type"].asString();
// 	std::string action = body_["action"].asString();
// 	led_state st;
// 
// 	if (strcmp("all","0") == 0)	{
// 		//SetAll(st);
// 		light_.set_all(led_state::on);
// 	}
// 
// }

void LightDevice::SetWhite() {
	value_ = "0";
	message_ = "success";
	try {
		if (!ActionLed())	{ 
			throw 0;
		}
		light_.set_white(st);
	}	catch (std::system_error &e){
		value_ = ErrCodeConver(e.code().value());
		message_ = e.what();
	}	catch (int &value){
		value_ = "-204";
		message_ = "json ��������[action]";
	}	catch (...)	{
		value_ = "-204";
		message_ = "δ֪����";
	}
	root_.clear();
	body_.clear();
	ResetJson(value_, message_);
}

void LightDevice::SetRed() {
	value_ = "0";
	message_ = "success";
	try {
		if (!ActionLed())	{
			throw 0;
		}
		light_.set_red(st);
	}	catch (std::system_error &e){
		value_ = ErrCodeConver(e.code().value());
		message_ = e.what();
	}	catch (int &value){
		value_ = "-204";
		message_ = "json ��������[action]";
	}	catch (...)	{
		value_ = "-204";
		message_ = "δ֪����";
	}
	root_.clear();
	body_.clear();
	ResetJson(value_, message_);
}

void LightDevice::SetGreen() {
	value_ = "0";
	message_ = "success";
	try {
		if (!ActionLed())	{
			throw 0;
		}
		light_.set_green(st);
	}	catch (std::system_error &e){
		value_ = ErrCodeConver(e.code().value());
		message_ = e.what();
	}	catch (int &value){
		value_ = "-204";
		message_ = "json ��������[action]";
	}	catch (...)	{
		value_ = "-204";
		message_ = "δ֪����";
	}
	root_.clear();
	body_.clear();
	ResetJson(value_, message_);
}

void LightDevice::SetCashIn() {
	value_ = "0";
	message_ = "success";
	try {
		if (!ActionLed())	{
			throw 0;
		}
		light_.set_cash_in(st);
	}	catch (std::system_error &e){
		value_ = ErrCodeConver(e.code().value());
		message_ = e.what();
	}	catch (int &value){
		value_ = "-204";
		message_ = "json ��������[action]";
	}	catch (...)	{
		value_ = "-204";
		message_ = "δ֪����";
	}
	root_.clear();
	body_.clear();
	ResetJson(value_, message_);
}

void LightDevice::SetCashOut() {
	value_ = "0";
	message_ = "success";
	try {
		if (!ActionLed())	{
			throw 0;
		}
		light_.set_cash_out(st);
	}	catch (std::system_error &e){
		value_ = ErrCodeConver(e.code().value());
		message_ = e.what();
	}	catch (int &value){
		value_ = "-204";
		message_ = "json ��������[action]";
	}	catch (...)	{
		value_ = "-204";
		message_ = "δ֪����";
	}
	root_.clear();
	body_.clear();
	ResetJson(value_, message_);
}

void LightDevice::SetEpp() {
	value_ = "0";
	message_ = "success";
	try {
		if (!ActionLed())	{
			throw 0;
		}
		light_.set_epp(st);
	}	catch (std::system_error &e){
		value_ = ErrCodeConver(e.code().value());
		message_ = e.what();
	}	catch (int &value){
		value_ = "-204";
		message_ = "json ��������[action]";
	}	catch (...)	{
		value_ = "-204";
		message_ = "δ֪����";
	}
	root_.clear();
	body_.clear();
	ResetJson(value_, message_);
}

void LightDevice::SetCard() {
	value_ = "0";
	message_ = "success";
	try {
		if (!ActionLed())	{
			throw 0;
		}
		light_.set_card(st);
	}	catch (std::system_error &e){
		value_ = ErrCodeConver(e.code().value());
		message_ = e.what();
	}	catch (int &value){
		value_ = "-204";
		message_ = "json ��������[action]";
	}	catch (...)	{
		value_ = "-204";
		message_ = "δ֪����";
	}
	root_.clear();
	body_.clear();
	ResetJson(value_, message_);
}

void LightDevice::SetEppL() {
	value_ = "0";
	message_ = "success";
	try {
		if (!ActionLed())	{
			throw 0;
		}
		light_.set_epp_l(st);
	}	catch (std::system_error &e){
		value_ = ErrCodeConver(e.code().value());
		message_ = e.what();
	}	catch (int &value){
		value_ = "-204";
		message_ = "json ��������[action]";
	}	catch (...)	{
		value_ = "-204";
		message_ = "δ֪����";
	}
	root_.clear();
	body_.clear();
	ResetJson(value_, message_);
}

void LightDevice::SetCashOutL() {
	value_ = "0";
	message_ = "success";
	try {
		if (!ActionLed())	{
			throw 0;
		}
		light_.set_cash_out_l(st);
	}	catch (std::system_error &e){
		value_ = ErrCodeConver(e.code().value());
		message_ = e.what();
	}	catch (int &value){
		value_ = "-204";
		message_ = "json ��������[action]";
	}	catch (...)	{
		value_ = "-204";
		message_ = "δ֪����";
	}
	root_.clear();
	body_.clear();
	ResetJson(value_, message_);
}

void LightDevice::SetLockL() {
	value_ = "0";
	message_ = "success";
	try {
		if (!ActionLed())	{
			throw 0;
		}
		light_.set_lock_l(st);
	}	catch (std::system_error &e){
		value_ = ErrCodeConver(e.code().value());
		message_ = e.what();
	} catch (int &value){
		value_ = "-204";
		message_ = "json ��������[action]";
	}	catch (...)	{
		value_ = "-204";
		message_ = "δ֪����";
	}
	root_.clear();
	body_.clear();
	ResetJson(value_, message_);
}

void LightDevice::SetAll() {
	value_ = "0";
	message_ = "success";
	try {
		if (!ActionLed())	{
			throw 0;
		}
		light_.set_all(st);
	}	catch (std::system_error &e){
		value_ = ErrCodeConver(e.code().value());
		message_ = e.what();
	}	catch (int &value){
		value_ = "-204";
		message_ = "json ��������[action]";
	}	catch (...)	{
		value_ = "-204";
		message_ = "δ֪����";
	}
	root_.clear();
	body_.clear();
	ResetJson(value_, message_);
}

BOOL LightDevice::IsJsonCheck() {
	try {
		if (!root_.isObject())	{
			throw 0;
		}
		CHECKJSONOBJECT("head", root_, "object");
		CHECKJSONOBJECT("body", root_, "object");
		CHECKJSONSTRING("device", root_["head"], "string");
		CHECKJSONSTRING("deviceType", root_["head"], "string");
		CHECKJSONSTRING("code", root_["head"], "string");
	}	catch (ProcessException &e) {
		value_ = "-204";
		message_ = "json ��������,";
		message_ = message_ + e.what();
		UnknownCmd("unkonwn", "-204", message_);
		return FALSE;
	}	catch (int &value) {
		UnknownCmd("unkonwn", "-204", "json ��ʽ����");
		return FALSE;
	}
	catch (...) {
		UnknownCmd("unkonwn", "-204", "json δ֪����");
		return FALSE;
	}
	return TRUE;
}

void LightDevice::ResetJson(std::string error, std::string message) {
	head_["errCode"] = error;
	head_["msg"] = message;
	root_["head"] = head_;
	root_["body"] = body_;
}

void LightDevice::UnknownCmd(std::string code, std::string error_code, std::string msg) {
	root_ = Json::Value();
	root_.clear();
	head_.clear();
	body_.clear();
	head_["device"] = "light";
	head_["deviceType"] = "0";
	head_["code"] = code;
	ResetJson(error_code, msg);
}

BOOL LightDevice::ActionLed() {
	if (body_["action"].isNull())	{
		return FALSE;
	}
	std::string action = body_["action"].asString();
	if (strcmp("on", action.c_str()) == 0)	{
		st = led_state::on;
	}
	else if (strcmp("off", action.c_str()) == 0)	{
		st = led_state::off;
	}
	else if (strcmp("blink", action.c_str()) == 0)	{
		st = led_state::blink;
	}
	else {
		return FALSE;
	}
	return TRUE;
}

std::string ErrCodeConver(int value) {
	std::string  str;
	char strBuff[64] = { 0 };
	sprintf(strBuff, "%d", value);
	str = strBuff;
	return str;
}
