
#include "exception.h"

ProcessException::ProcessException( const std::string &_error, const std::string &errorcode, int line, const std::string& filename, const std::string &type)
: std::exception(_error.c_str())
, _errorcode(errorcode)
, _line(line)
, _filename(filename)
, _type(type)
{

}

const std::string& ProcessException::getErrorcode() const
{
	return _errorcode;
}

int ProcessException::getLine() const
{
	return _line;
}

const std::string& ProcessException::getFilename() const
{
	return _filename;
}

const std::string& ProcessException::getType() const
{
	return _type;
}

SessionExcption::SessionExcption( int line, const std::string& filename, const std::string& type)
: ProcessException("session��֤ʧ��","A02", line , filename, type)
{

}

A03_ProcessException::A03_ProcessException( const std::string &name, int line, const std::string& filename,  const std::string &type)
	: ProcessException("["+ name + "]" + "�ύ��������(parameter error)", "A03", line, filename, type)
{

}

A05_ProcessException::A05_ProcessException( int line, const std::string& filename, const std::string& type)
: ProcessException("ҵ�����̺Ŵ���", "A05", line, filename, type)
{

}

A07_ProcessException::A07_ProcessException( const std::string &type,int line, const std::string& filename )
: ProcessException("�������ڲ�����", "A07", line , filename, type)
{

}

A08_ProcessException::A08_ProcessException( int line, const std::string& filename, const std::string& type)
: ProcessException("���ֲ����Ȩ����֤ʧ��","A08", line , filename, type)
{

}

A10_ProcessException::A10_ProcessException( const std::string &type,int line, const std::string& filename )
: ProcessException("�������ڲ���ʱ", "A10", line , filename, type)
{

}
